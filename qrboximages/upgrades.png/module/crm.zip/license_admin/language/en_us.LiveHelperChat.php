<?php

$mod_strings['LBL_LIVEHELPERCHAT'] = 'Live Helper Chat License';
$mod_strings['LBL_LIVEHELPERCHAT_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_LIVEHELPERCHAT_LICENSE'] = 'Manage and configure the license for this add-on';
