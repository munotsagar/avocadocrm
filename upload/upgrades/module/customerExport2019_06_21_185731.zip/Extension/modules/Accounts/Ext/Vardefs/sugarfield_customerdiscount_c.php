<?php
 // created: 2019-06-16 18:29:52
$dictionary['Account']['fields']['customerdiscount_c']['inline_edit']='1';
$dictionary['Account']['fields']['customerdiscount_c']['labelValue']='Customer Discount';

 ?>