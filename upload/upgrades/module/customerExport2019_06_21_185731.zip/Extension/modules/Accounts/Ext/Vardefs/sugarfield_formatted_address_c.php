<?php
 // created: 2019-06-16 18:29:53
$dictionary['Account']['fields']['formatted_address_c']['inline_edit']='1';
$dictionary['Account']['fields']['formatted_address_c']['labelValue']='Formatted Address';

 ?>