<?php
 // created: 2019-06-16 18:29:50
$dictionary['Account']['fields']['addr_status_c']['inline_edit']='1';
$dictionary['Account']['fields']['addr_status_c']['labelValue']='Addr Status';

 ?>