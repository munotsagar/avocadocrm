<?php
 // created: 2019-06-16 18:29:51
$dictionary['Account']['fields']['card3_c']['inline_edit']='1';
$dictionary['Account']['fields']['card3_c']['labelValue']='Card';

 ?>