<?php
 // created: 2019-06-16 18:29:51
$dictionary['Account']['fields']['card_number2_c']['inline_edit']='1';
$dictionary['Account']['fields']['card_number2_c']['labelValue']='Card Number';

 ?>