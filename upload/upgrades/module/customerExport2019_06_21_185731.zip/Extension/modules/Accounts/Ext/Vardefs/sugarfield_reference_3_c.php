<?php
 // created: 2019-06-16 18:29:55
$dictionary['Account']['fields']['reference_3_c']['inline_edit']='1';
$dictionary['Account']['fields']['reference_3_c']['labelValue']='Reference 3';

 ?>