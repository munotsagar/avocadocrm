<?php
 // created: 2019-06-16 18:29:52
$dictionary['Account']['fields']['customer_group_c']['inline_edit']='1';
$dictionary['Account']['fields']['customer_group_c']['labelValue']='Customer Group';

 ?>