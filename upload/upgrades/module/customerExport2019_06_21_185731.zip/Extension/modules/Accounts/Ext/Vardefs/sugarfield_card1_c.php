<?php
 // created: 2019-06-16 18:29:51
$dictionary['Account']['fields']['card1_c']['inline_edit']='1';
$dictionary['Account']['fields']['card1_c']['labelValue']='Card';

 ?>