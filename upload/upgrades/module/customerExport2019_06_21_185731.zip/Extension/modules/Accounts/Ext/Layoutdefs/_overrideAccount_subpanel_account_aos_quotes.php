<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['account_aos_quotes']['override_subpanel_name'] = 'Account_subpanel_account_aos_quotes';
?>