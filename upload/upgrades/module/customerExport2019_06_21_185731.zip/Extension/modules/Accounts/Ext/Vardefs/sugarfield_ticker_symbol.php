<?php
 // created: 2018-12-13 12:39:00
$dictionary['Account']['fields']['ticker_symbol']['inline_edit']=true;
$dictionary['Account']['fields']['ticker_symbol']['merge_filter']='disabled';
$dictionary['Account']['fields']['ticker_symbol']['len']='50';
$dictionary['Account']['fields']['ticker_symbol']['comments']='The stock trading (ticker) symbol for the company';

 ?>