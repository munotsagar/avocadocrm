<?php
 // created: 2019-06-29 16:20:30
$dictionary['prodr_Product_Driver_Stock']['fields']['product_c']['inline_edit']='1';
$dictionary['prodr_Product_Driver_Stock']['fields']['product_c']['labelValue']='Product';

 ?>