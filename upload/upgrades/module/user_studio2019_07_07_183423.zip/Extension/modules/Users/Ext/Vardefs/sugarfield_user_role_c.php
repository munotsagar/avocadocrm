<?php
 // created: 2019-07-06 13:48:08
$dictionary['User']['fields']['user_role_c']['inline_edit']='1';
$dictionary['User']['fields']['user_role_c']['labelValue']='User Role';

 ?>