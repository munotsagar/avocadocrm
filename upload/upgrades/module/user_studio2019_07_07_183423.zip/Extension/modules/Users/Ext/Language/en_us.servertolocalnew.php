<?php 
 // created: 2019-06-12 16:45:12
$mod_strings['LBL_COMMISION_RATE'] = 'Commision Rate';
$mod_strings['LBL_FLAT_RATE_COMMISSION'] = 'Flat Rate Commission';
$mod_strings['LBL_PERCENTAGE_COMMISSION'] = 'Percentage Commission';

?>
