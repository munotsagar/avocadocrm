<?php
 // created: 2019-06-16 18:29:56
$dictionary['User']['fields']['commision_rate_c']['inline_edit']='1';
$dictionary['User']['fields']['commision_rate_c']['labelValue']='Commision Rate';

 ?>