<?php 
 // created: 2019-07-07 18:33:46
$mod_strings['LBL_COMMISION_RATE'] = 'Commision Rate';
$mod_strings['LBL_USER_ROLE'] = 'User Role';

?>
