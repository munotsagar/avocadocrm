<?php 
$app_list_strings['user_type_dom'] = array (
  'RegularUser' => 'Driver',
  'Administrator' => 'Administrator',
  'Driver' => 'Driver',
);$app_list_strings['user_role_list'] = array (
  0 => 'Select User Role',
  'driverlocation' => 'Driver Location',
);