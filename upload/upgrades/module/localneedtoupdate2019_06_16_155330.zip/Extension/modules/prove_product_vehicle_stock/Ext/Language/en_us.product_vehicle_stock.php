<?php 
 // created: 2019-05-03 21:25:43
$mod_strings['LBL_PRODUCT_ID_AOS_PRODUCTS_ID'] = 'Product (related  ID)';
$mod_strings['LBL_PRODUCT_ID'] = 'Product';
$mod_strings['LBL_VEHICLE_ID_FYN_VEHICLE_ID'] = 'Vehicle (related  ID)';
$mod_strings['LBL_VEHICLE_ID'] = 'Vehicle';
$mod_strings['LBL_VEHICLE_STOCK'] = 'vehicle Stock';
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'undefined 1';

?>
