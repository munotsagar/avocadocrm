<?php
 // created: 2019-05-04 14:58:09
$dictionary['prove_product_vehicle_stock']['fields']['fyn_vehicle_id_c']['inline_edit']=1;

 ?>