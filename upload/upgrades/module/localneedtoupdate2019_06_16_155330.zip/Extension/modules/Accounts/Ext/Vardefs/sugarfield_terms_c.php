<?php
 // created: 2019-06-12 18:16:18
$dictionary['Account']['fields']['terms_c']['inline_edit']='1';
$dictionary['Account']['fields']['terms_c']['labelValue']='Net Terms';

 ?>