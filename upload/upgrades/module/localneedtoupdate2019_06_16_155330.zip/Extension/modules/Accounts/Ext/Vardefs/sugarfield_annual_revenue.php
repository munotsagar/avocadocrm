<?php
 // created: 2018-11-19 12:52:20
$dictionary['Account']['fields']['annual_revenue']['inline_edit']=true;
$dictionary['Account']['fields']['annual_revenue']['merge_filter']='disabled';

 ?>