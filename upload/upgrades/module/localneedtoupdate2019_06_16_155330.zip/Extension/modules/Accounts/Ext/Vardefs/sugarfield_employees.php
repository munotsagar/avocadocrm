<?php
 // created: 2018-12-13 18:10:45
$dictionary['Account']['fields']['employees']['inline_edit']=true;
$dictionary['Account']['fields']['employees']['merge_filter']='disabled';
$dictionary['Account']['fields']['employees']['len']='120';
$dictionary['Account']['fields']['employees']['comments']='Number of employees, varchar to accomodate for both number (100) or range (50-100)';

 ?>