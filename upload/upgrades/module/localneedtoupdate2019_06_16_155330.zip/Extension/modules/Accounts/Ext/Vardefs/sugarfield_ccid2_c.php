<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['ccid2_c']['inline_edit']='1';
$dictionary['Account']['fields']['ccid2_c']['labelValue']='CCID Number';

 ?>