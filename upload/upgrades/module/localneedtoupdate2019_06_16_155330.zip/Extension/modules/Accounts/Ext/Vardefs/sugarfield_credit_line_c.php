<?php
 // created: 2019-06-12 17:56:40
$dictionary['Account']['fields']['credit_line_c']['inline_edit']='1';
$dictionary['Account']['fields']['credit_line_c']['labelValue']='Credit Line';

 ?>