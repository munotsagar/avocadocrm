<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['mob_num_c']['inline_edit']='1';
$dictionary['Account']['fields']['mob_num_c']['labelValue']='mob num';

 ?>