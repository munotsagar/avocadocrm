<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['formatted_address_c']['inline_edit']='1';
$dictionary['Account']['fields']['formatted_address_c']['labelValue']='Formatted Address';

 ?>