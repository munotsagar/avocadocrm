<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['dateofbirth_c']['inline_edit']='1';
$dictionary['Account']['fields']['dateofbirth_c']['labelValue']='Date of Birth';

 ?>