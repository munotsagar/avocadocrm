<?php
 // created: 2018-11-19 12:54:37
$dictionary['Account']['fields']['account_type']['len']=100;
$dictionary['Account']['fields']['account_type']['inline_edit']=true;
$dictionary['Account']['fields']['account_type']['options']='account_type_list';
$dictionary['Account']['fields']['account_type']['merge_filter']='disabled';

 ?>