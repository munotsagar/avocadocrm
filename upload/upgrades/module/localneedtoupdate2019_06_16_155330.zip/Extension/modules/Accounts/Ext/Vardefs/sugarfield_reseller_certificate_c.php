<?php
 // created: 2019-06-11 16:32:06
$dictionary['Account']['fields']['reseller_certificate_c']['inline_edit']='1';
$dictionary['Account']['fields']['reseller_certificate_c']['labelValue']='Reseller Certificate';

 ?>