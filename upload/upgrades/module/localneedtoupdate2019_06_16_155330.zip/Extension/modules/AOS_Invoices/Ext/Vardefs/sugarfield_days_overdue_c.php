<?php
 // created: 2019-06-16 01:01:34
$dictionary['AOS_Invoices']['fields']['days_overdue_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['days_overdue_c']['options']='numeric_range_search_dom';
$dictionary['AOS_Invoices']['fields']['days_overdue_c']['labelValue']='Days Overdue';
$dictionary['AOS_Invoices']['fields']['days_overdue_c']['enable_range_search']='1';

 ?>