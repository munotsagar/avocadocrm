<?php
 // created: 2019-01-16 16:21:55
$dictionary['AOS_Invoices']['fields']['status']['default']='Unpaid';
$dictionary['AOS_Invoices']['fields']['status']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['status']['merge_filter']='disabled';

 ?>