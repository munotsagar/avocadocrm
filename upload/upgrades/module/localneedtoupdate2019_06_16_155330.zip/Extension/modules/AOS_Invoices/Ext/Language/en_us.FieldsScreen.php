<?php 
 // created: 2019-06-11 16:59:20
$mod_strings['LBL_BILLING_ACCOUNT'] = 'Customer';
$mod_strings['LBL_ACCOUNTS'] = 'Customers';
$mod_strings['LBL_AOS_QUOTES_AOS_INVOICES'] = 'Order: Invoices';
$mod_strings['LBL_AOS_INVOICES_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE'] = 'Stock Out';
$mod_strings['LBL_QUOTE_NUMBER'] = 'Order Number';
$mod_strings['LBL_QUOTE_DATE'] = 'Order Date';
$mod_strings['LBL_STATUS'] = 'Payment Status';
$mod_strings['LBL_ADDR_STATUS_C'] = 'Address Status';
$mod_strings['LBL_FORMATTED_ADDRESS_C'] = 'Formatted Address';
$mod_strings['LBL_AOS_INVOICES_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LBL_CUSTOMERID'] = 'CustomerID';
$mod_strings['LBL_ORDERID'] = 'OrderID';
$mod_strings['LBL_APPROVAL_STATUS'] = 'Invoice Status';
$mod_strings['LBL_SALES_COMMISSION_USER_USER_ID'] = 'Sales / Commission User (related User ID)';
$mod_strings['LBL_SALES_COMMISSION_USER'] = 'Sales / Commission User';
$mod_strings['LBL_COMMISSION_AMOUNT'] = 'Commission Amount';
$mod_strings['LBL_BALANCEAMOUNT'] = 'Balance Amount';
$mod_strings['LBL_EDITED'] = 'edited';
$mod_strings['LBL_ITEM1'] = 'Item1';
$mod_strings['LBL_ITEM2'] = 'Item2';
$mod_strings['LBL_ITEM3'] = 'Item3';
$mod_strings['LBL_ITEM4'] = 'Item4';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Product Availability';
$mod_strings['LBL_ITEM5'] = 'Item5';
$mod_strings['LBL_ITEM6'] = 'Item6';
$mod_strings['LBL_ITEM7'] = 'Item7';
$mod_strings['LBL_ITEM8'] = 'Item8';
$mod_strings['LBL_ITEM9'] = 'Item9';
$mod_strings['LBL_ITEM10'] = 'Item10';
$mod_strings['LBL_ITEM11'] = 'Item11';
$mod_strings['LBL_ITEM12'] = 'item12';
$mod_strings['LBL_ITEM13'] = 'Item13';
$mod_strings['LBL_ITEM14'] = 'Item14';
$mod_strings['LBL_ITEM15'] = 'Item15';
$mod_strings['LBL_DUE_DATE'] = 'Due Dateold';
$mod_strings['LBL_DUE_DATES'] = 'Due Date';

?>
