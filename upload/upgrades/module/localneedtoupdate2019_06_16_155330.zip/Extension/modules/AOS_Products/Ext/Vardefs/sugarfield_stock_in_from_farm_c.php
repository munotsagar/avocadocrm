<?php
 // created: 2019-06-12 19:12:57
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['labelValue']='Last Transaction Stock In ';

 ?>