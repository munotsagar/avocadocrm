<?php
 // created: 2019-06-14 06:30:18
$dictionary['AOS_Products']['fields']['testtwo_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['testtwo_c']['labelValue']='testtwo';

 ?>