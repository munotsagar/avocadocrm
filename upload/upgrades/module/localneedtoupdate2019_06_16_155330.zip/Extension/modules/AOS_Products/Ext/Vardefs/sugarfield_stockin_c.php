<?php
 // created: 2019-06-12 18:57:54
$dictionary['AOS_Products']['fields']['stockin_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stockin_c']['labelValue']='Total In Stock';

 ?>