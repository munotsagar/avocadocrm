<?php
 // created: 2018-11-19 20:37:26
$dictionary['AOS_Products']['fields']['type']['default']='';
$dictionary['AOS_Products']['fields']['type']['inline_edit']=true;
$dictionary['AOS_Products']['fields']['type']['options']='type_0';
$dictionary['AOS_Products']['fields']['type']['merge_filter']='disabled';

 ?>