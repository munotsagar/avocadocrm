<?php
 // created: 2019-06-11 16:32:04
$dictionary['AOS_Products']['fields']['reserve_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['reserve_c']['labelValue']='Reserve';

 ?>