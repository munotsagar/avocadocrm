<?php
 // created: 2019-06-04 17:59:41
$layout_defs["fyn_Stock_In"]["subpanel_setup"]['fyn_stock_in_fyn_qr_code_boxes_1'] = array (
  'order' => 100,
  'module' => 'fyn_QR_CODE_BOXES',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_FYN_STOCK_IN_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE',
  'get_subpanel_data' => 'fyn_stock_in_fyn_qr_code_boxes_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
