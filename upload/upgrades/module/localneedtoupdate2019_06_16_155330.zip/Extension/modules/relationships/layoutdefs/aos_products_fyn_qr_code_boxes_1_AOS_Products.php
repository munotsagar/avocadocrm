<?php
 // created: 2018-11-25 11:57:42
$layout_defs["AOS_Products"]["subpanel_setup"]['aos_products_fyn_qr_code_boxes_1'] = array (
  'order' => 100,
  'module' => 'fyn_QR_CODE_BOXES',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_PRODUCTS_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE',
  'get_subpanel_data' => 'aos_products_fyn_qr_code_boxes_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
