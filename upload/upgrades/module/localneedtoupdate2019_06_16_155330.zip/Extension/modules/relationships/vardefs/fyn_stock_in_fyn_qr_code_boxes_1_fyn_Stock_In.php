<?php
// created: 2019-06-04 17:59:41
$dictionary["fyn_Stock_In"]["fields"]["fyn_stock_in_fyn_qr_code_boxes_1"] = array (
  'name' => 'fyn_stock_in_fyn_qr_code_boxes_1',
  'type' => 'link',
  'relationship' => 'fyn_stock_in_fyn_qr_code_boxes_1',
  'source' => 'non-db',
  'module' => 'fyn_QR_CODE_BOXES',
  'bean_name' => 'fyn_QR_CODE_BOXES',
  'side' => 'right',
  'vname' => 'LBL_FYN_STOCK_IN_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE',
);
