<?php
// created: 2018-11-19 23:27:38
$dictionary["AOS_Products"]["fields"]["aos_products_fyn_stock_in_1"] = array (
  'name' => 'aos_products_fyn_stock_in_1',
  'type' => 'link',
  'relationship' => 'aos_products_fyn_stock_in_1',
  'source' => 'non-db',
  'module' => 'fyn_Stock_In',
  'bean_name' => 'fyn_Stock_In',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_FYN_STOCK_IN_1_FROM_FYN_STOCK_IN_TITLE',
);
