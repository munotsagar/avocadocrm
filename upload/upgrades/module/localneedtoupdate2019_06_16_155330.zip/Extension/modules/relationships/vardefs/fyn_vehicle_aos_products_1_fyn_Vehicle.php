<?php
// created: 2019-06-08 23:41:30
$dictionary["fyn_Vehicle"]["fields"]["fyn_vehicle_aos_products_1"] = array (
  'name' => 'fyn_vehicle_aos_products_1',
  'type' => 'link',
  'relationship' => 'fyn_vehicle_aos_products_1',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'vname' => 'LBL_FYN_VEHICLE_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE',
);
