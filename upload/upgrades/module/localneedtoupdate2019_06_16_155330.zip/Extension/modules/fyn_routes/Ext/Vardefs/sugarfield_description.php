<?php
 // created: 2019-05-18 12:44:19
$dictionary['fyn_routes']['fields']['description']['inline_edit']=true;
$dictionary['fyn_routes']['fields']['description']['comments']='Full text of the note';
$dictionary['fyn_routes']['fields']['description']['merge_filter']='disabled';

 ?>