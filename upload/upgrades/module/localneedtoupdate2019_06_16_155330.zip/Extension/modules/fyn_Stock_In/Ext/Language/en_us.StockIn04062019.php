<?php 
 // created: 2019-06-04 19:48:10
$mod_strings['LBL_DO_NOT_DELETE'] = 'do not delete';
$mod_strings['LBL_FROM1'] = 'From';
$mod_strings['LBL_SELECTVEHICLE_FYN_VEHICLE_ID'] = 'Select Vehicle (related  ID)';
$mod_strings['LBL_SELECTVEHICLE'] = 'Select Vehicle';
$mod_strings['LBL_QUANTITY'] = 'Quantity';
$mod_strings['LBL_NAME'] = 'Stock In Name';
$mod_strings['LBL_VENDER'] = 'Vender';
$mod_strings['LBL_DATE_ENTERED'] = 'Truck Info';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'undefined 1';
$mod_strings['LBL_STATUS'] = 'Status';

?>
