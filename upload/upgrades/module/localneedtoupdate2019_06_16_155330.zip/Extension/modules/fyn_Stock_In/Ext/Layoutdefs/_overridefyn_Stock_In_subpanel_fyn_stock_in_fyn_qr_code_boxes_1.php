<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_Stock_In']['subpanel_setup']['fyn_stock_in_fyn_qr_code_boxes_1']['override_subpanel_name'] = 'fyn_Stock_In_subpanel_fyn_stock_in_fyn_qr_code_boxes_1';
?>