<?php
 // created: 2019-06-04 17:50:22
$dictionary['fyn_Stock_In']['fields']['from1_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['from1_c']['labelValue']='From';

 ?>