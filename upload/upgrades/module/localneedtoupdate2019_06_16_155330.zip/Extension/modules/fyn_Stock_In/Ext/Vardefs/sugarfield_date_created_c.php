<?php
 // created: 2019-06-12 19:29:18
$dictionary['fyn_Stock_In']['fields']['date_created_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['date_created_c']['labelValue']='Date Created';

 ?>