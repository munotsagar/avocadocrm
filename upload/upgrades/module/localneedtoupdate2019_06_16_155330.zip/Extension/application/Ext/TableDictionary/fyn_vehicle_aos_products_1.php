<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/fyn_vehicle_aos_products_1MetaData.php');

?>