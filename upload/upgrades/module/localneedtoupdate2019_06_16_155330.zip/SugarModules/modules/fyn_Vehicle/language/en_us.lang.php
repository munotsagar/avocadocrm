<?php 
 // created: 2019-06-16 15:53:24
$mod_strings['LBL_FYN_VEHICLE_VS_VEHICLE_STOCKIN_1_FROM_VS_VEHICLE_STOCKIN_TITLE'] = 'Vehicle StockIN';
$mod_strings['LBL_FYN_VEHICLE_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LBL_NAME'] = 'Driver Name';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Drivers';
$mod_strings['LBL_FYN_VEHICLE_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE'] = 'Products';

?>
