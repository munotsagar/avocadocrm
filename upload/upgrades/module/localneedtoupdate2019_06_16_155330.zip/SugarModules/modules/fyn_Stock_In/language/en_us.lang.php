<?php 
 // created: 2019-06-16 15:53:23
$mod_strings['LBL_DO_NOT_DELETE'] = 'do not delete';
$mod_strings['LBL_FROM1'] = 'From';
$mod_strings['LBL_SELECTVEHICLE_FYN_VEHICLE_ID'] = 'Select Vehicle (related  ID)';
$mod_strings['LBL_SELECTVEHICLE'] = 'Select Vehicle';
$mod_strings['LBL_QUANTITY'] = 'Quantity';
$mod_strings['LBL_NAME'] = 'Stock In Name';
$mod_strings['LBL_FYN_STOCK_IN_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE'] = 'QR Code Boxes';
$mod_strings['LBL_DATE_CREATED'] = 'Date Created';
$mod_strings['LBL_DATE_ENTERED'] = 'Date Created';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'New Panel 1';

?>
