<?php 
 // created: 2019-06-16 15:53:15
$mod_strings['LBL_ACCOUNT_NAME'] = 'Customer Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Customer ID:';
$mod_strings['LBL_ACCOUNT'] = 'Customer';
$mod_strings['LBL_AOS_QUOTES'] = 'Order';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Customer Name';

?>
