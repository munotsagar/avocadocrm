<?php 
 // created: 2019-06-16 15:53:11
$mod_strings['LBL_CUSTOMERS_PURCHASED_PRODUCTS_SUBPANEL_TITLE'] = 'Purchases';
$mod_strings['LBL_PART_NUMBER'] = 'Product ID';
$mod_strings['LBL_TYPE'] = 'Warehouse Stock Status';
$mod_strings['LBL_TRUCK'] = 'Truck';
$mod_strings['LBL_STOCKIN'] = 'Total In Stock';
$mod_strings['LBL_STOCKOUT'] = 'Stock Out';
$mod_strings['LBL_BALANCE'] = 'Warehouse Balance Stock';
$mod_strings['LBL_PRODUCT_MODEL_CODE'] = 'Product Model Code';
$mod_strings['LBL_STAGGING_INVENTORY'] = 'Today New Orders';
$mod_strings['LBL_OPENCARTBALANCESTOCK'] = 'Balance Stock after New Orders';
$mod_strings['LBL_AOS_PRODUCTS_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE'] = 'Stock Out';
$mod_strings['LBL_AOS_PRODUCTS_FYN_STOCK_IN_1_FROM_FYN_STOCK_IN_TITLE'] = 'Stock In';
$mod_strings['LBL_AOS_PRODUCTS_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE'] = 'QR Code Boxes';
$mod_strings['LBL_MAINCODE'] = 'OpenCart Stock Status';
$mod_strings['LBL_AOS_PRODUCTS_VS_VEHICLE_STOCKIN_1_FROM_VS_VEHICLE_STOCKIN_TITLE'] = 'Vehicle StockIN';
$mod_strings['LBL_AOS_PRODUCTS_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LBL_ORDER_UPDATE_DAILY'] = 'Order Update Daily';
$mod_strings['LBL_FOR_DAILYUPDATEORDER'] = 'For Daily update order';
$mod_strings['LBL_CATEGORY'] = 'Product Category';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Locations at Main Warehouse';
$mod_strings['LBL_STOCK_IN_FROM_FARM'] = 'Last Order Stock In';
$mod_strings['LBL_NAME'] = 'Product Name';
$mod_strings['LBL_TESTTWO'] = 'testtwo';

?>
