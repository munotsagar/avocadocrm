<?php 
 // created: 2019-06-16 15:53:25
$mod_strings['LBL_VEHICLE_ID'] = 'Vehicle';

?>
