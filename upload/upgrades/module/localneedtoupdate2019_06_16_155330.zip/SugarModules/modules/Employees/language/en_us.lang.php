<?php 
 // created: 2019-06-16 15:53:21
$mod_strings['LBL_COMMISION_RATE'] = 'Commision Rate';
$mod_strings['LBL_FLAT_RATE_COMMISSION'] = 'Flat Rate Commission';
$mod_strings['LBL_PERCENTAGE_COMMISSION'] = 'Percentage Commission';

?>
