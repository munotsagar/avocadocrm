<?php
// created: 2019-06-08 23:41:30
$dictionary["AOS_Products"]["fields"]["fyn_vehicle_aos_products_1"] = array (
  'name' => 'fyn_vehicle_aos_products_1',
  'type' => 'link',
  'relationship' => 'fyn_vehicle_aos_products_1',
  'source' => 'non-db',
  'module' => 'fyn_Vehicle',
  'bean_name' => 'fyn_Vehicle',
  'vname' => 'LBL_FYN_VEHICLE_AOS_PRODUCTS_1_FROM_FYN_VEHICLE_TITLE',
);
