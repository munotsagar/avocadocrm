<?php
 // created: 2019-06-11 16:32:06
$dictionary['Account']['fields']['reference_1_c']['inline_edit']='1';
$dictionary['Account']['fields']['reference_1_c']['labelValue']='Reference 1';

 ?>