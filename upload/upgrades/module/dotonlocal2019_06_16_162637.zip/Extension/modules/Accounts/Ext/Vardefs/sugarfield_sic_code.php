<?php
 // created: 2018-11-19 12:46:59
$dictionary['Account']['fields']['sic_code']['inline_edit']=true;
$dictionary['Account']['fields']['sic_code']['merge_filter']='disabled';

 ?>