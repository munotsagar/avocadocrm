<?php
 // created: 2019-06-11 16:32:06
$dictionary['Account']['fields']['totalnooforders_c']['inline_edit']='1';
$dictionary['Account']['fields']['totalnooforders_c']['labelValue']='Total No Of Orders';

 ?>