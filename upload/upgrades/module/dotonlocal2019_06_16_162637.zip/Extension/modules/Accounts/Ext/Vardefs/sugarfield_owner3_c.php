<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['owner3_c']['inline_edit']='1';
$dictionary['Account']['fields']['owner3_c']['labelValue']='Name Appears on the Card';

 ?>