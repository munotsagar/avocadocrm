<?php
 // created: 2019-06-11 16:32:05
$dictionary['AOS_Products']['fields']['warehouse_balance_stocks_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['warehouse_balance_stocks_c']['labelValue']='Warehouse Balance Stocks';

 ?>