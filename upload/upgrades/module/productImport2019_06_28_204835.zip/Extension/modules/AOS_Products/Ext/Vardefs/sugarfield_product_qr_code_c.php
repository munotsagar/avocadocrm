<?php
 // created: 2019-06-16 18:29:49
$dictionary['AOS_Products']['fields']['product_qr_code_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_qr_code_c']['labelValue']='Product QR Code';

 ?>