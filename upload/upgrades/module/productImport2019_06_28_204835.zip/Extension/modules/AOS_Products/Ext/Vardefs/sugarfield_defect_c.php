<?php
 // created: 2019-06-16 18:29:48
$dictionary['AOS_Products']['fields']['defect_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['defect_c']['labelValue']='Defect';

 ?>