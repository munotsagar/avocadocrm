<?php
 // created: 2018-11-16 12:58:27
$dictionary['fyn_vehicles']['fields']['stockin_c']['inline_edit']='1';
$dictionary['fyn_vehicles']['fields']['stockin_c']['labelValue']='Stock IN';

 ?>