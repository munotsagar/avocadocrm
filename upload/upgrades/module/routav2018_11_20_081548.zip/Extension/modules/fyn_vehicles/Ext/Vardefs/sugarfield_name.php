<?php
 // created: 2018-09-11 16:32:32
$dictionary['fyn_vehicles']['fields']['name']['inline_edit']=true;
$dictionary['fyn_vehicles']['fields']['name']['duplicate_merge']='disabled';
$dictionary['fyn_vehicles']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['fyn_vehicles']['fields']['name']['merge_filter']='disabled';
$dictionary['fyn_vehicles']['fields']['name']['unified_search']=false;

 ?>