<?php
 // created: 2018-11-16 12:58:36
$dictionary['fyn_vehicles']['fields']['stockout_c']['inline_edit']='1';
$dictionary['fyn_vehicles']['fields']['stockout_c']['labelValue']='Stock OUT';

 ?>