<?php
 // created: 2018-11-16 12:58:45
$dictionary['fyn_vehicles']['fields']['balstock_c']['inline_edit']='1';
$dictionary['fyn_vehicles']['fields']['balstock_c']['labelValue']='Bal Stock';

 ?>