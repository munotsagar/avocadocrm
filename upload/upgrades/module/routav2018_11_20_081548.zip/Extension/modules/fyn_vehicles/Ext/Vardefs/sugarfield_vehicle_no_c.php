<?php
 // created: 2018-08-17 19:34:32
$dictionary['fyn_vehicles']['fields']['vehicle_no_c']['inline_edit']='1';
$dictionary['fyn_vehicles']['fields']['vehicle_no_c']['labelValue']='Vehicle Number';

 ?>