<?php
// created: 2018-08-17 17:38:34
$dictionary["fyn_vlzs"]["fields"]["fyn_vlzs_fyn_routes_1"] = array (
  'name' => 'fyn_vlzs_fyn_routes_1',
  'type' => 'link',
  'relationship' => 'fyn_vlzs_fyn_routes_1',
  'source' => 'non-db',
  'module' => 'fyn_routes',
  'bean_name' => 'fyn_routes',
  'side' => 'right',
  'vname' => 'LBL_FYN_VLZS_FYN_ROUTES_1_FROM_FYN_ROUTES_TITLE',
);
