<?php
// created: 2018-09-24 13:44:59
$dictionary["fyn_locations"]["fields"]["fyn_vlzs_fyn_locations_1"] = array (
  'name' => 'fyn_vlzs_fyn_locations_1',
  'type' => 'link',
  'relationship' => 'fyn_vlzs_fyn_locations_1',
  'source' => 'non-db',
  'module' => 'fyn_vlzs',
  'bean_name' => 'fyn_vlzs',
  'vname' => 'LBL_FYN_VLZS_FYN_LOCATIONS_1_FROM_FYN_VLZS_TITLE',
);
