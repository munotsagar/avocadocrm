<?php
 // created: 2018-08-17 17:38:34
$layout_defs["fyn_vlzs"]["subpanel_setup"]['fyn_vlzs_fyn_routes_1'] = array (
  'order' => 100,
  'module' => 'fyn_routes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_FYN_VLZS_FYN_ROUTES_1_FROM_FYN_ROUTES_TITLE',
  'get_subpanel_data' => 'fyn_vlzs_fyn_routes_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
