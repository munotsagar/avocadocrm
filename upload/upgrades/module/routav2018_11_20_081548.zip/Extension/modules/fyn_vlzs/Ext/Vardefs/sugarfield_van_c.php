<?php
 // created: 2018-10-16 01:12:25
$dictionary['fyn_vlzs']['fields']['van_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['van_c']['labelValue']='Van';

 ?>