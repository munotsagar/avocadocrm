<?php
 // created: 2018-09-11 11:25:12
$dictionary['fyn_vlzs']['fields']['status_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['status_c']['labelValue']='Status';

 ?>