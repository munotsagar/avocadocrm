<?php
 // created: 2018-10-16 01:12:25
$dictionary['fyn_vlzs']['fields']['fyn_vehicles_id_c']['inline_edit']=1;

 ?>