<?php
 // created: 2018-09-11 11:25:08
$dictionary['fyn_vlzs']['fields']['zone_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['zone_c']['labelValue']='Select Zone';

 ?>