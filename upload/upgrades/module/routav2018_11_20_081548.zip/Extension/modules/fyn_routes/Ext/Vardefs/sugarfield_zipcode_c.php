<?php
 // created: 2018-10-28 20:03:58
$dictionary['fyn_routes']['fields']['zipcode_c']['inline_edit']='1';
$dictionary['fyn_routes']['fields']['zipcode_c']['labelValue']='ZipCode';

 ?>