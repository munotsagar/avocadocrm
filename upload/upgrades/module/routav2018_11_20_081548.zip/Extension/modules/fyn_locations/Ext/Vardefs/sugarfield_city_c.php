<?php
 // created: 2018-09-24 13:36:54
$dictionary['fyn_locations']['fields']['city_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['city_c']['labelValue']='City';

 ?>