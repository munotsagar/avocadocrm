<?php
 // created: 2018-10-18 22:11:09
$dictionary['fyn_locations']['fields']['county_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['county_c']['labelValue']='County';

 ?>