<?php
 // created: 2018-10-19 19:52:24
$dictionary['fyn_locations']['fields']['name']['inline_edit']=true;
$dictionary['fyn_locations']['fields']['name']['duplicate_merge']='disabled';
$dictionary['fyn_locations']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['fyn_locations']['fields']['name']['merge_filter']='disabled';
$dictionary['fyn_locations']['fields']['name']['unified_search']=false;
$dictionary['fyn_locations']['fields']['name']['required']=false;

 ?>