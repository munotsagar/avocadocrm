<?php
 // created: 2018-10-19 19:51:44
$dictionary['fyn_locations']['fields']['location_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['location_c']['labelValue']='Location';

 ?>