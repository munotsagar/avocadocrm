<?php 
 // created: 2018-11-20 08:15:48
$mod_strings['LBL_FYN_ROUTES_OP_ORDERS_1_FROM_OP_ORDERS_TITLE'] = 'Orders';
$mod_strings['LBL_FYN_VLZS_FYN_ROUTES_1_FROM_FYN_VLZS_TITLE'] = 'VLZs';
$mod_strings['LNK_NEW_RECORD'] = 'Create Routes';
$mod_strings['LNK_LIST'] = 'View Routes';
$mod_strings['LNK_IMPORT_FYN_ROUTES'] = 'Import Routes';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Routes List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Routes';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Routes';
$mod_strings['LBL_ZIPCODE'] = 'ZipCode';

?>
