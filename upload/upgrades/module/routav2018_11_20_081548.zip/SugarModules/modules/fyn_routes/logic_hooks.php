<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
$hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['before_save'] = Array(); 
$hook_array['after_save'] = Array(); 


$hook_array['before_save'][] = Array(1, 'test', 'custom/modules/fyn_routes/test.php','Test', 'testing'); 
$hook_array['before_save'][] = Array(4, 'auto', 'custom/modules/fyn_routes/auto.php','auto', 'relate');


?>