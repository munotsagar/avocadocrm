<?php 
 // created: 2018-11-20 08:15:48
$mod_strings['LBL_NAME'] = 'Zip Code';
$mod_strings['LNK_NEW_RECORD'] = 'Create Areas';
$mod_strings['LNK_LIST'] = 'View Areas';
$mod_strings['LNK_IMPORT_FYN_LOCATIONS'] = 'Import Areas';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Area List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Area';
$mod_strings['LBL_FYN_VLZS_FYN_LOCATIONS_1_FROM_FYN_VLZS_TITLE'] = '3 - VAZs';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Areas';
$mod_strings['LBL_COUNTY'] = 'County';
$mod_strings['LBL_CITY'] = 'City';
$mod_strings['LBL_STATE'] = 'State';
$mod_strings['LBL_ZIPCODE'] = 'Zip Code';
$mod_strings['LBL_LOCATION'] = 'Area';

?>
