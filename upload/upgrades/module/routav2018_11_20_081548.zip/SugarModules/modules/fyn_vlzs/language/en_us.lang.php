<?php 
 // created: 2018-11-20 08:15:48
$mod_strings['LBL_ZONE_C'] = 'Select Area';
$mod_strings['LBL_STATUS_C'] = 'Status';
$mod_strings['LNK_NEW_RECORD'] = 'Create Vehicle&Areas';
$mod_strings['LNK_LIST'] = 'View Vehicle&Areas';
$mod_strings['LNK_IMPORT_FYN_VLZS'] = 'Import Vehicle&Areas';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Vehicle&Area List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Vehicle&Area';
$mod_strings['LBL_FYN_VLZS_FYN_LOCATIONS_1_FROM_FYN_LOCATIONS_TITLE'] = 'Area';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Vehicle&Areas';
$mod_strings['LBL_FYN_VLZS_FYN_VEHICLES_1_FROM_FYN_VEHICLES_TITLE'] = '1 - Vehicles';
$mod_strings['LBL_FYN_VLZS_FYN_ROUTES_1_FROM_FYN_ROUTES_TITLE'] = 'Routes';
$mod_strings['LBL_VAN_FYN_VEHICLES_ID'] = 'Van (related 1 - Vehicles ID)';
$mod_strings['LBL_VAN'] = 'Van';

?>
