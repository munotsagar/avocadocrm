<?php 
 // created: 2018-11-20 08:15:48
$mod_strings['LBL_VEHICLE_NO_C'] = 'Vehicle Number';
$mod_strings['LBL_NAME'] = 'Vehicle Name';
$mod_strings['LBL_FYN_VLZS_FYN_VEHICLES_1_FROM_FYN_VLZS_TITLE'] = 'VLZs';
$mod_strings['LNK_NEW_RECORD'] = 'Create Vehicles';
$mod_strings['LNK_LIST'] = 'View Vehicles';
$mod_strings['LNK_IMPORT_FYN_VEHICLES'] = 'Import Vehicles';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Vehicles List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Vehicles';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Vehicles';
$mod_strings['LBL_STOCKIN'] = 'Stock IN';
$mod_strings['LBL_STOCKOUT'] = 'Stock OUT';
$mod_strings['LBL_BALSTOCK'] = 'Bal Stock';
$mod_strings['LBL_FYN_VEHICLES_ST_STOCK_OUT_1_FROM_ST_STOCK_OUT_TITLE'] = 'Stock-Ins (Warehouse To Van)';
$mod_strings['LBL_FYN_VEHICLES_ST_STOCK_IN_1_FROM_ST_STOCK_IN_TITLE'] = 'Stock-Outs (Van to Warehouse)';

?>
