<?php 
$app_list_strings['zone_c_list'] = array (
  '' => '',
  'san_diego' => 'San Diego',
  'san_bernardino' => 'San Bernardino',
  'Riverside' => 'Riverside',
  'South_OC' => 'South OC',
  'north_LA_and_FWY_LCBF' => 'North LA 14 and 5 FWY LC-BF',
  'Ventura_Zips' => 'Ventura Zips',
  'SVG_and_North_OC' => 'SVG and North OC',
  'LA' => 'LA',
);$app_list_strings['status_c_list'] = array (
  '' => '',
  'active' => 'Active',
  'inactive' => 'Inactive',
);