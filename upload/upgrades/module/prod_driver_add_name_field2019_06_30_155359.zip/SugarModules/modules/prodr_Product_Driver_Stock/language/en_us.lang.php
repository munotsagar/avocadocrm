<?php 
 // created: 2019-06-30 15:53:56
$mod_strings['LBL_PRODUCT_AOS_PRODUCTS_ID'] = 'Product (related  ID)';
$mod_strings['LBL_PRODUCT'] = 'Product';
$mod_strings['LBL_DRIVER_USER_ID'] = 'Driver (related User ID)';
$mod_strings['LBL_DRIVER'] = 'Driver';
$mod_strings['LBL_STOCK'] = 'Stock';

?>
