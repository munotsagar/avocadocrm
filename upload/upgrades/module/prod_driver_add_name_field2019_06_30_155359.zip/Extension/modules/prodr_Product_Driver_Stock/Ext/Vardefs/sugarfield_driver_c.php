<?php
 // created: 2019-06-29 16:23:36
$dictionary['prodr_Product_Driver_Stock']['fields']['driver_c']['inline_edit']='1';
$dictionary['prodr_Product_Driver_Stock']['fields']['driver_c']['labelValue']='Driver';

 ?>