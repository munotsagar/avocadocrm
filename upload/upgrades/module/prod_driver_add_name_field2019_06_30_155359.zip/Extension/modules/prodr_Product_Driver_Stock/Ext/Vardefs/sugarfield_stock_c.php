<?php
 // created: 2019-06-29 16:24:38
$dictionary['prodr_Product_Driver_Stock']['fields']['stock_c']['inline_edit']='1';
$dictionary['prodr_Product_Driver_Stock']['fields']['stock_c']['labelValue']='Stock';

 ?>