<?php
 // created: 2019-06-29 16:20:30
$dictionary['prodr_Product_Driver_Stock']['fields']['aos_products_id_c']['inline_edit']=1;

 ?>