<?php
 // created: 2019-07-07 16:53:48
$dictionary['dc_driver_commission']['fields']['invoice_c']['inline_edit']='1';
$dictionary['dc_driver_commission']['fields']['invoice_c']['labelValue']='Invoice';

 ?>