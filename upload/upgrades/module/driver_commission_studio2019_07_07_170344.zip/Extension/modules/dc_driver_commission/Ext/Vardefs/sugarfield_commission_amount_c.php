<?php
 // created: 2019-07-07 16:58:58
$dictionary['dc_driver_commission']['fields']['commission_amount_c']['inline_edit']='1';
$dictionary['dc_driver_commission']['fields']['commission_amount_c']['labelValue']='Commission Amount';

 ?>