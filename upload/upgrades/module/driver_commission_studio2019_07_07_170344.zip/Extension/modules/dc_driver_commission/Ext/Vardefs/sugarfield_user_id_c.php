<?php
 // created: 2019-07-07 16:52:42
$dictionary['dc_driver_commission']['fields']['user_id_c']['inline_edit']=1;

 ?>