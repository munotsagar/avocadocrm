<?php
 // created: 2019-07-07 16:56:51
$dictionary['dc_driver_commission']['fields']['flat_rate_commission_c']['inline_edit']='1';
$dictionary['dc_driver_commission']['fields']['flat_rate_commission_c']['labelValue']='Flat Rate Commission';

 ?>