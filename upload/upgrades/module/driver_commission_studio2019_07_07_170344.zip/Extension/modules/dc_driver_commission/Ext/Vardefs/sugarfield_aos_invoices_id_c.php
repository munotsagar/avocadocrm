<?php
 // created: 2019-07-07 16:53:48
$dictionary['dc_driver_commission']['fields']['aos_invoices_id_c']['inline_edit']=1;

 ?>