<?php
 // created: 2019-07-07 16:57:54
$dictionary['dc_driver_commission']['fields']['percentage_commission_c']['inline_edit']='1';
$dictionary['dc_driver_commission']['fields']['percentage_commission_c']['labelValue']='Percentage Commission';

 ?>