<?php 
 // created: 2019-07-07 17:03:41
$mod_strings['LBL_DRIVER_USER_ID'] = 'Driver (related User ID)';
$mod_strings['LBL_DRIVER'] = 'Driver';
$mod_strings['LBL_INVOICE_AOS_INVOICES_ID'] = 'Invoice (related  ID)';
$mod_strings['LBL_INVOICE'] = 'Invoice';
$mod_strings['LBL_FLAT_RATE_COMMISSION'] = 'Flat Rate Commission';
$mod_strings['LBL_PERCENTAGE_COMMISSION'] = 'Percentage Commission';
$mod_strings['LBL_COMMISSION_AMOUNT'] = 'Commission Amount';

?>
