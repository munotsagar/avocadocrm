<?php
 // created: 2019-06-11 18:06:24
$dictionary['AOS_Invoices']['fields']['total_commission_amount_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['total_commission_amount_c']['labelValue']='Total Commission Amount';

 ?>