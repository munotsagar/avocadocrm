<?php
 // created: 2019-06-11 17:31:09
$dictionary['User']['fields']['flat_rate_commission_c']['inline_edit']='1';
$dictionary['User']['fields']['flat_rate_commission_c']['labelValue']='Flat Rate Commission';

 ?>