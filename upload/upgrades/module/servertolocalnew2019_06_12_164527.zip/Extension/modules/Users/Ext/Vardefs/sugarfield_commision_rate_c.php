<?php
 // created: 2018-12-11 11:49:37
$dictionary['User']['fields']['commision_rate_c']['inline_edit']='1';
$dictionary['User']['fields']['commision_rate_c']['labelValue']='Commision Rate';

 ?>