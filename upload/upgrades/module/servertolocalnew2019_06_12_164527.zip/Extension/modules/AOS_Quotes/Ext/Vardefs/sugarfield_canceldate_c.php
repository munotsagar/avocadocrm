<?php
 // created: 2018-11-19 17:25:03
$dictionary['AOS_Quotes']['fields']['canceldate_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['canceldate_c']['labelValue']='Cancel Date';

 ?>