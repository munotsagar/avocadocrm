<?php
 // created: 2018-12-11 11:54:36
$dictionary['AOS_Quotes']['fields']['user_id_c']['inline_edit']=1;

 ?>