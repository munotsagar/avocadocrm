<?php
 // created: 2018-12-11 12:40:55
$dictionary['AOS_Quotes']['fields']['commission_amount_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['commission_amount_c']['labelValue']='Commission Amount';

 ?>