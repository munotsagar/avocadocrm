<?php
 // created: 2018-11-19 17:24:32
$dictionary['AOS_Quotes']['fields']['refunddate_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['refunddate_c']['labelValue']='Refund Date';

 ?>