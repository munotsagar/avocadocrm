<?php
 // created: 2019-01-16 16:09:14
$dictionary['AOS_Quotes']['fields']['due_dates_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['due_dates_c']['labelValue']='Due Date';

 ?>