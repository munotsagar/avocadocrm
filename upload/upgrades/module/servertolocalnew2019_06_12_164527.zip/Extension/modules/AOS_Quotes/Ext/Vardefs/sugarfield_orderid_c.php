<?php
 // created: 2018-11-19 17:05:07
$dictionary['AOS_Quotes']['fields']['orderid_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['orderid_c']['labelValue']='Order ID';

 ?>