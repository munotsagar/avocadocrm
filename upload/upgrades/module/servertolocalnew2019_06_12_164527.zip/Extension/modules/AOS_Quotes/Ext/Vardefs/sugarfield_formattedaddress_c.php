<?php
 // created: 2018-11-22 01:54:31
$dictionary['AOS_Quotes']['fields']['formattedaddress_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['formattedaddress_c']['labelValue']='Formatted Address text feild';

 ?>