<?php
 // created: 2018-12-04 18:28:35
$dictionary['AOS_Quotes']['fields']['name']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['name']['duplicate_merge']='disabled';
$dictionary['AOS_Quotes']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['AOS_Quotes']['fields']['name']['merge_filter']='disabled';
$dictionary['AOS_Quotes']['fields']['name']['unified_search']=false;
$dictionary['AOS_Quotes']['fields']['name']['required']=false;

 ?>