<?php
 // created: 2018-12-03 19:38:52
$dictionary['AOS_Quotes']['fields']['approval_status']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['approval_status']['merge_filter']='disabled';
$dictionary['AOS_Quotes']['fields']['approval_status']['options']='approval_status_list';

 ?>