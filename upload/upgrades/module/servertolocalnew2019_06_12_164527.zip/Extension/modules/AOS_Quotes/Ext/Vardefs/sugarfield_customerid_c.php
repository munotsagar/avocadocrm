<?php
 // created: 2018-11-19 17:02:18
$dictionary['AOS_Quotes']['fields']['customerid_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['customerid_c']['labelValue']='Customer ID';

 ?>