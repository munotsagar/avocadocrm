<?php
 // created: 2018-11-22 01:54:44
$dictionary['AOS_Quotes']['fields']['formatted_address_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['formatted_address_c']['labelValue']='Formatted Address';

 ?>