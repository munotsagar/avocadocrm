<?php
 // created: 2018-11-19 13:07:11
$dictionary['Account']['fields']['industry']['len']=100;
$dictionary['Account']['fields']['industry']['inline_edit']=true;
$dictionary['Account']['fields']['industry']['options']='industry_list';
$dictionary['Account']['fields']['industry']['comments']='The company belongs in this industry';
$dictionary['Account']['fields']['industry']['merge_filter']='disabled';

 ?>