<?php
 // created: 2018-11-19 12:49:45
$dictionary['Account']['fields']['ownership']['inline_edit']=true;
$dictionary['Account']['fields']['ownership']['merge_filter']='disabled';

 ?>