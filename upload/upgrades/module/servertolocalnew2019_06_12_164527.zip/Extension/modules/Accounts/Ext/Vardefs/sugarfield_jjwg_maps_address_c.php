<?php
 // created: 2019-06-11 16:32:05
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>