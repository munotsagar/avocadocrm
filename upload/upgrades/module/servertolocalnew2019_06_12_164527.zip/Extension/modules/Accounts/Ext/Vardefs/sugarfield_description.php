<?php
 // created: 2018-11-19 13:19:47
$dictionary['Account']['fields']['description']['inline_edit']=true;
$dictionary['Account']['fields']['description']['comments']='Full text of the note';
$dictionary['Account']['fields']['description']['merge_filter']='disabled';

 ?>