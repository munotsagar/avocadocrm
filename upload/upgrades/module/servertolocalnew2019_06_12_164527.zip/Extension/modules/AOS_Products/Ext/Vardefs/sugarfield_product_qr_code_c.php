<?php
 // created: 2019-06-11 16:32:04
$dictionary['AOS_Products']['fields']['product_qr_code_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_qr_code_c']['labelValue']='Product QR Code';

 ?>