<?php
 // created: 2019-06-11 16:32:04
$dictionary['AOS_Products']['fields']['backorders_count_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['backorders_count_c']['labelValue']='Backorders Count';

 ?>