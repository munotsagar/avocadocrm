<?php 
 // created: 2019-06-12 16:45:02
$mod_strings['LBL_ACCOUNT'] = 'Customer';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Customer Description';
$mod_strings['LBL_ACCOUNT_ID'] = 'Customer ID';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Customer Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Customer Name';
$mod_strings['LBL_CONVERTED_ACCOUNT'] = 'Converted Customer:';
$mod_strings['LNK_SELECT_ACCOUNTS'] = ' OR Select Customer';
$mod_strings['LNK_NEW_ACCOUNT'] = 'Create Customer';

?>
