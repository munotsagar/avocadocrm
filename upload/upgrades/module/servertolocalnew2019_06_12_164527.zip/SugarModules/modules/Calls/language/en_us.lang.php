<?php 
 // created: 2019-06-12 16:45:00
$mod_strings['LBL_ACCOUNT'] = 'Customer';

?>
