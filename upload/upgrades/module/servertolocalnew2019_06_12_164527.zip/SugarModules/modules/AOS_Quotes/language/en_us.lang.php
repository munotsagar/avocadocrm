<?php 
 // created: 2019-06-12 16:44:56
$mod_strings['LNK_NEW_RECORD'] = 'Create Order';
$mod_strings['LNK_LIST'] = 'View Orders';
$mod_strings['MSG_SHOW_DUPLICATES'] = 'Creating this account may potentially create a duplicate account. You may either click on Save to continue creating this new account with the previously entered data or you may click Cancel.';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Order List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Order';
$mod_strings['LBL_BILLING_ACCOUNT'] = 'Customer';
$mod_strings['LBL_ACCOUNTS'] = 'Customers';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Orders';
$mod_strings['LBL_NAME'] = 'Order Name';
$mod_strings['LBL_CUSTOMERID'] = 'Customer ID';
$mod_strings['LBL_APPROVAL_STATUS'] = 'Order Status';
$mod_strings['LBL_EXPIRATION'] = 'Due Dateold';
$mod_strings['LBL_BALANCEAMOUNT'] = 'Balance Amount';
$mod_strings['LBL_ORDERID'] = 'Order ID';
$mod_strings['LBL_ADDR_STATUS'] = 'Address Status';
$mod_strings['LBL_CANCELREASON'] = 'Cancel Reason';
$mod_strings['LBL_REFUNDREASON'] = 'Refund Reason';
$mod_strings['LBL_REFUNDDATE'] = 'Refund Date';
$mod_strings['LBL_CANCELDATE'] = 'Cancel Date';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Order Name';
$mod_strings['LBL_BILLING_ADDRESS_POSTALCODE'] = 'Billing Zip Code';
$mod_strings['LBL_FORMATTEDADDRESS'] = 'Formatted Address text feild';
$mod_strings['LBL_DO_NO_DELETE'] = 'do no delete';
$mod_strings['LBL_FORMATTED_ADDRESS'] = 'Formatted Address';
$mod_strings['LBL_COMPANY_NAME'] = 'Company Name';
$mod_strings['LBL_AOS_QUOTES_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE'] = 'Stock Out';
$mod_strings['LBL_AOS_QUOTES_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LBL_STAGE'] = 'Quote Stage';
$mod_strings['LBL_SALES_COMMISSION_USER_USER_ID'] = 'Sales / Commission User (related User ID)';
$mod_strings['LBL_SALES_COMMISSION_USER'] = 'Sales / Commission User';
$mod_strings['LBL_COMMISSION_AMOUNT'] = 'Commission Amount';
$mod_strings['LBL_UPDATED'] = 'updated';
$mod_strings['LBL_SPECIAL_SUGGESTION'] = 'special suggestion';
$mod_strings['LBL_DUE_DATES'] = 'Due Date';

?>
