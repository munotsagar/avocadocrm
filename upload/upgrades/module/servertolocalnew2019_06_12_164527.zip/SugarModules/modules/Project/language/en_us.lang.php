<?php 
 // created: 2019-06-12 16:45:08
$mod_strings['LBL_ACCOUNTS'] = 'Customers';
$mod_strings['LBL_AOS_QUOTES_PROJECT'] = 'Order: Project';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Customers';

?>
