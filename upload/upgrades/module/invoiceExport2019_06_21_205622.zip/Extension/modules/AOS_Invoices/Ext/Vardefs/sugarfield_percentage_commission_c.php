<?php
 // created: 2019-06-16 18:29:47
$dictionary['AOS_Invoices']['fields']['percentage_commission_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['percentage_commission_c']['labelValue']='Percentage Commission';

 ?>