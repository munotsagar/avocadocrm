<?php
 // created: 2019-06-16 18:29:45
$dictionary['AOS_Invoices']['fields']['due_dates_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['due_dates_c']['labelValue']='Due Date';

 ?>