<?php
 // created: 2019-06-16 18:29:46
$dictionary['AOS_Invoices']['fields']['item9_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item9_c']['labelValue']='Item9';

 ?>