<?php
 // created: 2019-06-11 17:52:37
$dictionary['AOS_Invoices']['fields']['billing_account']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['billing_account']['merge_filter']='disabled';
$dictionary['AOS_Invoices']['fields']['billing_account']['help']='Account Name';
$dictionary['AOS_Invoices']['fields']['billing_account']['comments']='Account Name';

 ?>