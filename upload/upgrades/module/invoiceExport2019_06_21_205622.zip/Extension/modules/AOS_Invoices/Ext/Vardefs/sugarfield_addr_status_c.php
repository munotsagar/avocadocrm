<?php
 // created: 2019-06-16 18:29:44
$dictionary['AOS_Invoices']['fields']['addr_status_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['addr_status_c']['labelValue']='Address Status';

 ?>