<?php
 // created: 2019-06-16 18:29:45
$dictionary['AOS_Invoices']['fields']['flat_rate_commission_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['flat_rate_commission_c']['labelValue']='Flat Rate Commission';

 ?>