<?php
 // created: 2018-11-30 13:16:37
$dictionary['fyn_Stock_In']['fields']['from1_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['from1_c']['labelValue']='From';

 ?>