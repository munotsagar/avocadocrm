<?php
 // created: 2018-11-20 19:43:02
$dictionary['fyn_Stock_In']['fields']['do_not_delete_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['do_not_delete_c']['labelValue']='do not delete';

 ?>