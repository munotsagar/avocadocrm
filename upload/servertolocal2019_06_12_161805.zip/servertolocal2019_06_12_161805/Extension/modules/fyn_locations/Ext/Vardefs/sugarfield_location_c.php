<?php
 // created: 2018-12-01 09:50:03
$dictionary['fyn_locations']['fields']['location_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['location_c']['labelValue']='Area';

 ?>