<?php
// created: 2018-12-01 15:02:29
$dictionary["fyn_locations"]["fields"]["fyn_locations_aos_invoices_1"] = array (
  'name' => 'fyn_locations_aos_invoices_1',
  'type' => 'link',
  'relationship' => 'fyn_locations_aos_invoices_1',
  'source' => 'non-db',
  'module' => 'AOS_Invoices',
  'bean_name' => 'AOS_Invoices',
  'side' => 'right',
  'vname' => 'LBL_FYN_LOCATIONS_AOS_INVOICES_1_FROM_AOS_INVOICES_TITLE',
);
