<?php
 // created: 2018-12-01 09:46:57
$dictionary['fyn_locations']['fields']['country_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['country_c']['labelValue']='Country';

 ?>