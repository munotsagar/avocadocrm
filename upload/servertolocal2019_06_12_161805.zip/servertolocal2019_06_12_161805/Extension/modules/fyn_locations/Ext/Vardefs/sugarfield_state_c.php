<?php
 // created: 2018-12-01 09:50:39
$dictionary['fyn_locations']['fields']['state_c']['inline_edit']='1';
$dictionary['fyn_locations']['fields']['state_c']['labelValue']='State';

 ?>