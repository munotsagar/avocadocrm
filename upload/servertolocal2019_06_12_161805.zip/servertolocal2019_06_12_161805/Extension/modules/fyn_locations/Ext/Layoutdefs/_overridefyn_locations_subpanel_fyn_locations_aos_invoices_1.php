<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_locations']['subpanel_setup']['fyn_locations_aos_invoices_1']['override_subpanel_name'] = 'fyn_locations_subpanel_fyn_locations_aos_invoices_1';
?>