<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Products']['subpanel_setup']['aos_products_vs_vehicle_stockin_1']['override_subpanel_name'] = 'AOS_Products_subpanel_aos_products_vs_vehicle_stockin_1';
?>