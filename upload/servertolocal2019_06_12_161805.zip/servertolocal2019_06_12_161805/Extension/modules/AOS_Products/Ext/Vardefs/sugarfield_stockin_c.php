<?php
 // created: 2019-06-11 17:18:09
$dictionary['AOS_Products']['fields']['stockin_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stockin_c']['labelValue']='Total In Stock';

 ?>