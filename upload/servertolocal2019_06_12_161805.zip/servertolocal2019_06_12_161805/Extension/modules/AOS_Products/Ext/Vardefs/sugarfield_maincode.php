<?php
 // created: 2018-11-30 00:26:36
$dictionary['AOS_Products']['fields']['maincode']['default']='';
$dictionary['AOS_Products']['fields']['maincode']['inline_edit']=true;
$dictionary['AOS_Products']['fields']['maincode']['merge_filter']='disabled';

 ?>