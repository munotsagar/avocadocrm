<?php
// created: 2018-11-25 11:57:42
$dictionary["AOS_Products"]["fields"]["aos_products_fyn_qr_code_boxes_1"] = array (
  'name' => 'aos_products_fyn_qr_code_boxes_1',
  'type' => 'link',
  'relationship' => 'aos_products_fyn_qr_code_boxes_1',
  'source' => 'non-db',
  'module' => 'fyn_QR_CODE_BOXES',
  'bean_name' => 'fyn_QR_CODE_BOXES',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE',
);
