<?php
 // created: 2018-11-19 11:15:46
$dictionary['Meeting']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>