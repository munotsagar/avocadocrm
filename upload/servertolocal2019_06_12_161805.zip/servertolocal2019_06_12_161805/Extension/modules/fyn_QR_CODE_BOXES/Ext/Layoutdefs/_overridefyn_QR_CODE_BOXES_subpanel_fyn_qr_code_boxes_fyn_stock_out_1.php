<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_QR_CODE_BOXES']['subpanel_setup']['fyn_qr_code_boxes_fyn_stock_out_1']['override_subpanel_name'] = 'fyn_QR_CODE_BOXES_subpanel_fyn_qr_code_boxes_fyn_stock_out_1';
?>