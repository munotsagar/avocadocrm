<?php
// created: 2018-11-25 11:54:47
$dictionary["fyn_QR_CODE_BOXES"]["fields"]["fyn_qr_code_boxes_fyn_stock_in_1"] = array (
  'name' => 'fyn_qr_code_boxes_fyn_stock_in_1',
  'type' => 'link',
  'relationship' => 'fyn_qr_code_boxes_fyn_stock_in_1',
  'source' => 'non-db',
  'module' => 'fyn_Stock_In',
  'bean_name' => 'fyn_Stock_In',
  'side' => 'right',
  'vname' => 'LBL_FYN_QR_CODE_BOXES_FYN_STOCK_IN_1_FROM_FYN_STOCK_IN_TITLE',
);
