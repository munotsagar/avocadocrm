<?php
// created: 2018-12-03 17:45:45
$dictionary["fyn_QR_CODE_BOXES"]["fields"]["fyn_qr_code_boxes_vs_vehiclestockout_1"] = array (
  'name' => 'fyn_qr_code_boxes_vs_vehiclestockout_1',
  'type' => 'link',
  'relationship' => 'fyn_qr_code_boxes_vs_vehiclestockout_1',
  'source' => 'non-db',
  'module' => 'vs_vehiclestockOUT',
  'bean_name' => 'vs_vehiclestockOUT',
  'side' => 'right',
  'vname' => 'LBL_FYN_QR_CODE_BOXES_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE',
);
