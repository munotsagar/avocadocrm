<?php
// created: 2018-11-25 11:53:30
$dictionary["fyn_QR_CODE_BOXES"]["fields"]["fyn_qr_code_boxes_fyn_stock_out_1"] = array (
  'name' => 'fyn_qr_code_boxes_fyn_stock_out_1',
  'type' => 'link',
  'relationship' => 'fyn_qr_code_boxes_fyn_stock_out_1',
  'source' => 'non-db',
  'module' => 'fyn_Stock_out',
  'bean_name' => 'fyn_Stock_out',
  'side' => 'right',
  'vname' => 'LBL_FYN_QR_CODE_BOXES_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE',
);
