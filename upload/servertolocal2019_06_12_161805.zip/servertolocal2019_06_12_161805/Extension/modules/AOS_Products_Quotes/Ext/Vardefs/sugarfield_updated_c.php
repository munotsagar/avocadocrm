<?php
 // created: 2018-12-12 19:38:27
$dictionary['AOS_Products_Quotes']['fields']['updated_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['updated_c']['labelValue']='Updated';

 ?>