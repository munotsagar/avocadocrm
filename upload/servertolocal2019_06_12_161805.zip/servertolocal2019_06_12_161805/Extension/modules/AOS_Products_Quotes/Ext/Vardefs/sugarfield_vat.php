<?php
 // created: 2018-12-23 15:01:47
$dictionary['AOS_Products_Quotes']['fields']['vat']['default']='';
$dictionary['AOS_Products_Quotes']['fields']['vat']['inline_edit']=true;
$dictionary['AOS_Products_Quotes']['fields']['vat']['merge_filter']='disabled';

 ?>