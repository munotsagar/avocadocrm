<?php
 // created: 2018-11-19 17:04:30
$dictionary['AOS_Quotes']['fields']['balanceamount_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['balanceamount_c']['labelValue']='Balance Amount';

 ?>