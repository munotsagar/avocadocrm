<?php
 // created: 2019-01-16 16:14:04
$dictionary['AOS_Quotes']['fields']['expiration']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['expiration']['merge_filter']='disabled';
$dictionary['AOS_Quotes']['fields']['expiration']['required']=false;
$dictionary['AOS_Quotes']['fields']['expiration']['display_default']='';

 ?>