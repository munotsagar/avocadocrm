<?php
 // created: 2018-12-26 10:37:13
$dictionary['AOS_Quotes']['fields']['special_suggestion_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['special_suggestion_c']['labelValue']='special suggestion';

 ?>