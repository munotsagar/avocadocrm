<?php
 // created: 2018-11-19 17:20:48
$dictionary['AOS_Quotes']['fields']['cancelreason_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['cancelreason_c']['labelValue']='Cancel Reason';

 ?>