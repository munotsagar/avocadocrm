<?php
 // created: 2018-12-11 11:54:36
$dictionary['AOS_Quotes']['fields']['sales_commission_user_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['sales_commission_user_c']['labelValue']='Sales / Commission User';

 ?>