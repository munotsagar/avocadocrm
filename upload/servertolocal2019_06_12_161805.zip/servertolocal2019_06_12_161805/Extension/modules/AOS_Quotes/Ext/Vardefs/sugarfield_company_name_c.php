<?php
 // created: 2018-11-27 19:50:35
$dictionary['AOS_Quotes']['fields']['company_name_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['company_name_c']['labelValue']='Company Name';

 ?>