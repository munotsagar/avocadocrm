<?php
 // created: 2018-11-19 17:18:49
$dictionary['AOS_Quotes']['fields']['addr_status_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['addr_status_c']['labelValue']='Address Status';

 ?>