<?php
 // created: 2018-11-19 17:23:59
$dictionary['AOS_Quotes']['fields']['refundreason_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['refundreason_c']['labelValue']='Refund Reason';

 ?>