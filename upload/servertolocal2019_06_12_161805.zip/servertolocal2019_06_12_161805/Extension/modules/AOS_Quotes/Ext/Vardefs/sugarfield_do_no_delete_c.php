<?php
 // created: 2018-11-20 23:18:33
$dictionary['AOS_Quotes']['fields']['do_no_delete_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['do_no_delete_c']['labelValue']='do no delete';

 ?>