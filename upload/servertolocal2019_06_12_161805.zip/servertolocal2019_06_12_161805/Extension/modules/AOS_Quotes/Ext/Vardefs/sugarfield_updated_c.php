<?php
 // created: 2018-12-12 23:29:54
$dictionary['AOS_Quotes']['fields']['updated_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['updated_c']['labelValue']='updated';

 ?>