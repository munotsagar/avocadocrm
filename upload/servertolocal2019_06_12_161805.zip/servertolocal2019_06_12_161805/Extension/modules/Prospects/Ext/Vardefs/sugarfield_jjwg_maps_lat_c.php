<?php
 // created: 2018-11-19 11:15:47
$dictionary['Prospect']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>