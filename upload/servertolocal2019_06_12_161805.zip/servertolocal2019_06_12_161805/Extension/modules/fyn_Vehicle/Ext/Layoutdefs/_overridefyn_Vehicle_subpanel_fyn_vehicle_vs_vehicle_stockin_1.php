<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_Vehicle']['subpanel_setup']['fyn_vehicle_vs_vehicle_stockin_1']['override_subpanel_name'] = 'fyn_Vehicle_subpanel_fyn_vehicle_vs_vehicle_stockin_1';
?>