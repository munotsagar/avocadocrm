<?php
// created: 2018-11-30 17:28:41
$dictionary["fyn_Vehicle"]["fields"]["fyn_vehicle_vs_vehiclestockout_1"] = array (
  'name' => 'fyn_vehicle_vs_vehiclestockout_1',
  'type' => 'link',
  'relationship' => 'fyn_vehicle_vs_vehiclestockout_1',
  'source' => 'non-db',
  'module' => 'vs_vehiclestockOUT',
  'bean_name' => 'vs_vehiclestockOUT',
  'side' => 'right',
  'vname' => 'LBL_FYN_VEHICLE_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE',
);
