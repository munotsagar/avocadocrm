<?php
 // created: 2018-12-07 22:39:56
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_96_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_96_c']['labelValue']='Class1 Box 96';

 ?>