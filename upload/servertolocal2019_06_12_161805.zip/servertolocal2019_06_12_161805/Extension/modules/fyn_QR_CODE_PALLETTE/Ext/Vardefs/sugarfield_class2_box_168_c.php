<?php
 // created: 2018-12-07 22:51:45
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_168_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_168_c']['labelValue']='Class2 Box 168';

 ?>