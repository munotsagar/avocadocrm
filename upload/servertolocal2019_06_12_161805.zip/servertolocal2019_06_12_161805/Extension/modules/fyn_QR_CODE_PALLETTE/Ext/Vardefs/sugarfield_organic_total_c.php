<?php
 // created: 2018-11-26 08:18:05
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_total_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_total_c']['labelValue']='Organic Total';

 ?>