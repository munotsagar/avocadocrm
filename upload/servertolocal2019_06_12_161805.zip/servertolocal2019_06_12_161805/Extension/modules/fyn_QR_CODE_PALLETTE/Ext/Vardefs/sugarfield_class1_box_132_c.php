<?php
 // created: 2018-12-07 22:47:12
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_132_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_132_c']['labelValue']='Class1 Box 132';

 ?>