<?php
 // created: 2018-12-07 22:50:54
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_108_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_108_c']['labelValue']='Class2 Box 108';

 ?>