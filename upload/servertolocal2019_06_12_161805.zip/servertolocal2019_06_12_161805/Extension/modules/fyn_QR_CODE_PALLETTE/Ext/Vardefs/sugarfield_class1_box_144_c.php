<?php
 // created: 2018-12-07 22:48:17
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_144_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_144_c']['labelValue']='Class1 Box 144';

 ?>