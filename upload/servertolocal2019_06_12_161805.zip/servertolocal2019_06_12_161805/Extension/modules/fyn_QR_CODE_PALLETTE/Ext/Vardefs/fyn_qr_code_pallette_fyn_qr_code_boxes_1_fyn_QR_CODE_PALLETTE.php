<?php
// created: 2018-11-25 11:52:24
$dictionary["fyn_QR_CODE_PALLETTE"]["fields"]["fyn_qr_code_pallette_fyn_qr_code_boxes_1"] = array (
  'name' => 'fyn_qr_code_pallette_fyn_qr_code_boxes_1',
  'type' => 'link',
  'relationship' => 'fyn_qr_code_pallette_fyn_qr_code_boxes_1',
  'source' => 'non-db',
  'module' => 'fyn_QR_CODE_BOXES',
  'bean_name' => 'fyn_QR_CODE_BOXES',
  'side' => 'right',
  'vname' => 'LBL_FYN_QR_CODE_PALLETTE_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE',
);
