<?php
 // created: 2018-11-26 08:12:29
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_28_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_28_c']['labelValue']='Class2 Box 28';

 ?>