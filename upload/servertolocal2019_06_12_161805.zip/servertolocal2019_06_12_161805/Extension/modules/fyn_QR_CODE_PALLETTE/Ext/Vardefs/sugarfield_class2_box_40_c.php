<?php
 // created: 2018-11-26 08:14:19
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_40_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_40_c']['labelValue']='Class2 Box 40';

 ?>