<?php
 // created: 2018-12-07 22:50:32
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_96_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_96_c']['labelValue']='Class2 Box 96';

 ?>