<?php
 // created: 2018-11-26 08:16:43
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_36_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_36_c']['labelValue']='Organic Box 36';

 ?>