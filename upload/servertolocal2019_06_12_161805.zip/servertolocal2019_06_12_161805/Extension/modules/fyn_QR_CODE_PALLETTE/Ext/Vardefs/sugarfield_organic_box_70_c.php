<?php
 // created: 2018-11-26 08:17:04
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_70_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_70_c']['labelValue']='Organic Box 70';

 ?>