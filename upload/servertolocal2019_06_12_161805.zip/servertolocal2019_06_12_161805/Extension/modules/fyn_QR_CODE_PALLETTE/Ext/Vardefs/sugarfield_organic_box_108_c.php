<?php
 // created: 2018-12-07 22:53:30
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_108_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_108_c']['labelValue']='Organic Box 108';

 ?>