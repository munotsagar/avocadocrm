<?php
 // created: 2018-12-07 22:54:11
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_156_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_156_c']['labelValue']='Organic Box 156';

 ?>