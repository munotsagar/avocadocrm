<?php
 // created: 2018-12-07 22:53:40
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_120_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_120_c']['labelValue']='Organic Box 120';

 ?>