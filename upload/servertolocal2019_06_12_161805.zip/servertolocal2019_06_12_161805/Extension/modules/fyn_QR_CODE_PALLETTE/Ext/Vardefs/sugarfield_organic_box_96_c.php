<?php
 // created: 2018-12-07 22:53:21
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_96_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['organic_box_96_c']['labelValue']='Organic Box 96';

 ?>