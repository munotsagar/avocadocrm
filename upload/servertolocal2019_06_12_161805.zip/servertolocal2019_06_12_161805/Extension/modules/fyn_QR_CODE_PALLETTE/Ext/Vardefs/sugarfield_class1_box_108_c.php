<?php
 // created: 2018-12-07 22:40:17
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_108_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_108_c']['labelValue']='Class1 Box 108';

 ?>