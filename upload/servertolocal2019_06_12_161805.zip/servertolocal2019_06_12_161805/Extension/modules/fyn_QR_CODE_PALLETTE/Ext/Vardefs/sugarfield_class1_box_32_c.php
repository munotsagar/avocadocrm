<?php
 // created: 2018-11-26 08:08:34
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_32_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_32_c']['labelValue']='Class1 Box 32';

 ?>