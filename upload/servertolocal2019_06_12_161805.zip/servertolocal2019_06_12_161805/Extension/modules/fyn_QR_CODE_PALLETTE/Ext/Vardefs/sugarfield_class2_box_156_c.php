<?php
 // created: 2018-12-07 22:51:33
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_156_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_156_c']['labelValue']='Class2 Box 156';

 ?>