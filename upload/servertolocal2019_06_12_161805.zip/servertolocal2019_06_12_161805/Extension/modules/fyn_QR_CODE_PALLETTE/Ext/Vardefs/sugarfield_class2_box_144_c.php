<?php
 // created: 2018-12-07 22:51:24
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_144_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class2_box_144_c']['labelValue']='Class2 Box 144';

 ?>