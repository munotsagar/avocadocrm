<?php
 // created: 2018-11-26 22:16:25
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['product_model_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['product_model_c']['labelValue']='Product Model';

 ?>