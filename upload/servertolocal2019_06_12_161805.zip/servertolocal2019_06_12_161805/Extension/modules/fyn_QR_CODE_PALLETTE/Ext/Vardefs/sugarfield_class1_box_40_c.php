<?php
 // created: 2018-11-26 08:10:13
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_40_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_box_40_c']['labelValue']='Class1 Box 40';

 ?>