<?php
 // created: 2018-11-26 08:11:03
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_total_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_PALLETTE']['fields']['class1_total_c']['labelValue']='Class1 Total';

 ?>