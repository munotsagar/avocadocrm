<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_QR_CODE_PALLETTE']['subpanel_setup']['fyn_qr_code_pallette_fyn_qr_code_boxes_1']['override_subpanel_name'] = 'fyn_QR_CODE_PALLETTE_subpanel_fyn_qr_code_pallette_fyn_qr_code_boxes_1';
?>