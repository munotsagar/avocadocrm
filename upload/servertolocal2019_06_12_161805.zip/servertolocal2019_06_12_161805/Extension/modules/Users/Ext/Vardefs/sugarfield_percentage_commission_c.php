<?php
 // created: 2019-06-11 17:32:11
$dictionary['User']['fields']['percentage_commission_c']['inline_edit']='1';
$dictionary['User']['fields']['percentage_commission_c']['labelValue']='Percentage Commission';

 ?>