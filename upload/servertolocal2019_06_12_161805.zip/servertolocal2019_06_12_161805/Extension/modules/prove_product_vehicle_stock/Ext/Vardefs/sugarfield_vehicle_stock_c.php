<?php
 // created: 2019-05-04 14:58:10
$dictionary['prove_product_vehicle_stock']['fields']['vehicle_stock_c']['inline_edit']='1';
$dictionary['prove_product_vehicle_stock']['fields']['vehicle_stock_c']['labelValue']='vehicle Stock';

 ?>