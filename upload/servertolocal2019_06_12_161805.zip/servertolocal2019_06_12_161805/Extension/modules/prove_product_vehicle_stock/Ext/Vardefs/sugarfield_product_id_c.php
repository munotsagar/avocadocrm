<?php
 // created: 2019-05-04 14:58:09
$dictionary['prove_product_vehicle_stock']['fields']['product_id_c']['inline_edit']='1';
$dictionary['prove_product_vehicle_stock']['fields']['product_id_c']['labelValue']='Product';

 ?>