<?php
 // created: 2019-05-18 12:44:01
$dictionary['fyn_routes']['fields']['date_entered']['comments']='Date record created';
$dictionary['fyn_routes']['fields']['date_entered']['merge_filter']='disabled';

 ?>