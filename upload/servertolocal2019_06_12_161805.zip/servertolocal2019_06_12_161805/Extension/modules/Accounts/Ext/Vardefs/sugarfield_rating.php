<?php
 // created: 2018-11-19 13:44:18
$dictionary['Account']['fields']['rating']['inline_edit']=true;
$dictionary['Account']['fields']['rating']['help']='';
$dictionary['Account']['fields']['rating']['merge_filter']='disabled';

 ?>