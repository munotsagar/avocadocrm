<?php
// created: 2019-06-11 17:08:59
$dictionary["Account"]["fields"]["accounts_fp_events_2"] = array (
  'name' => 'accounts_fp_events_2',
  'type' => 'link',
  'relationship' => 'accounts_fp_events_2',
  'source' => 'non-db',
  'module' => 'FP_events',
  'bean_name' => 'FP_events',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_FP_EVENTS_2_FROM_FP_EVENTS_TITLE',
);
