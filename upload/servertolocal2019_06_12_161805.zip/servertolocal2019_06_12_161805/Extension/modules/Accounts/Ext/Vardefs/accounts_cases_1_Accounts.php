<?php
// created: 2019-06-11 17:07:06
$dictionary["Account"]["fields"]["accounts_cases_1"] = array (
  'name' => 'accounts_cases_1',
  'type' => 'link',
  'relationship' => 'accounts_cases_1',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_CASES_1_FROM_CASES_TITLE',
);
