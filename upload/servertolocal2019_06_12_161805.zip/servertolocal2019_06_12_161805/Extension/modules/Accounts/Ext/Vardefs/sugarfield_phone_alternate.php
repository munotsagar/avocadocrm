<?php
 // created: 2018-11-19 12:45:38
$dictionary['Account']['fields']['phone_alternate']['inline_edit']=true;
$dictionary['Account']['fields']['phone_alternate']['comments']='An alternate phone number';
$dictionary['Account']['fields']['phone_alternate']['merge_filter']='disabled';

 ?>