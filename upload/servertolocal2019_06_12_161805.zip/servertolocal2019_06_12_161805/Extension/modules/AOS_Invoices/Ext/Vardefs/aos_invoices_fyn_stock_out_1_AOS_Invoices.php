<?php
// created: 2018-11-29 19:26:13
$dictionary["AOS_Invoices"]["fields"]["aos_invoices_fyn_stock_out_1"] = array (
  'name' => 'aos_invoices_fyn_stock_out_1',
  'type' => 'link',
  'relationship' => 'aos_invoices_fyn_stock_out_1',
  'source' => 'non-db',
  'module' => 'fyn_Stock_out',
  'bean_name' => 'fyn_Stock_out',
  'side' => 'right',
  'vname' => 'LBL_AOS_INVOICES_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE',
);
