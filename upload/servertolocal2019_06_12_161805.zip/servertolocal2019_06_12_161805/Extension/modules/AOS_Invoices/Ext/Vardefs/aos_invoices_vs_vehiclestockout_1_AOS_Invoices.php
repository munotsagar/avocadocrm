<?php
// created: 2018-12-03 17:25:55
$dictionary["AOS_Invoices"]["fields"]["aos_invoices_vs_vehiclestockout_1"] = array (
  'name' => 'aos_invoices_vs_vehiclestockout_1',
  'type' => 'link',
  'relationship' => 'aos_invoices_vs_vehiclestockout_1',
  'source' => 'non-db',
  'module' => 'vs_vehiclestockOUT',
  'bean_name' => 'vs_vehiclestockOUT',
  'side' => 'right',
  'vname' => 'LBL_AOS_INVOICES_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE',
);
