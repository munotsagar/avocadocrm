<?php
 // created: 2019-06-11 16:32:04
$dictionary['AOS_Invoices']['fields']['customerid_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['customerid_c']['labelValue']='CustomerID';

 ?>