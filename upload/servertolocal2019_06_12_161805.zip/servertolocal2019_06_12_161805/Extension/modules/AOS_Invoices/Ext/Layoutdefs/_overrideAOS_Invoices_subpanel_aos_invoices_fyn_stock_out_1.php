<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Invoices']['subpanel_setup']['aos_invoices_fyn_stock_out_1']['override_subpanel_name'] = 'AOS_Invoices_subpanel_aos_invoices_fyn_stock_out_1';
?>