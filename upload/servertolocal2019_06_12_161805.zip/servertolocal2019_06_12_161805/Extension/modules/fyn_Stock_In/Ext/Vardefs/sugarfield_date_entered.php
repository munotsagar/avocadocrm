<?php
 // created: 2019-05-26 19:27:42
$dictionary['fyn_Stock_In']['fields']['date_entered']['comments']='Date record created';
$dictionary['fyn_Stock_In']['fields']['date_entered']['merge_filter']='disabled';

 ?>