<?php
 // created: 2019-06-04 17:50:22
$dictionary['fyn_Stock_In']['fields']['fyn_vehicle_id_c']['inline_edit']=1;

 ?>