<?php
 // created: 2018-12-01 00:31:55
$dictionary['fyn_Stock_out']['fields']['name']['required']=false;
$dictionary['fyn_Stock_out']['fields']['name']['full_text_search']=array (
);

 ?>