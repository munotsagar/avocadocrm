<?php
 // created: 2018-12-03 17:59:40
$dictionary['fyn_Stock_out']['fields']['destination_c']['inline_edit']='1';
$dictionary['fyn_Stock_out']['fields']['destination_c']['labelValue']='Destination';

 ?>