<?php
 // created: 2018-11-30 13:19:27
$dictionary['fyn_Stock_out']['fields']['select_vehicle_c']['inline_edit']='1';
$dictionary['fyn_Stock_out']['fields']['select_vehicle_c']['labelValue']='Select Vehicle';

 ?>