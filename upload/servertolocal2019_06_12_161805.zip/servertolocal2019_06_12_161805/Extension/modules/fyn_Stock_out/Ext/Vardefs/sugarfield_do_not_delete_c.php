<?php
 // created: 2018-12-05 00:13:43
$dictionary['fyn_Stock_out']['fields']['do_not_delete_c']['inline_edit']='1';
$dictionary['fyn_Stock_out']['fields']['do_not_delete_c']['labelValue']='do not delete';

 ?>