<?php
 // created: 2018-12-12 18:47:47
$dictionary['fyn_Stock_out']['fields']['quantity']['default']='1';

 ?>