<?php
 // created: 2018-11-30 13:19:27
$dictionary['fyn_Stock_out']['fields']['fyn_vehicle_id_c']['inline_edit']=1;

 ?>