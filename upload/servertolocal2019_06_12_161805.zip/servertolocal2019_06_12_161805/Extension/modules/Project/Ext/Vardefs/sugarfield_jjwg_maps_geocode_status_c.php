<?php
 // created: 2018-11-19 11:15:47
$dictionary['Project']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>