<?php
 // created: 2018-12-01 10:00:10
$dictionary['fyn_vlzs']['fields']['van_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['van_c']['labelValue']='Van';

 ?>