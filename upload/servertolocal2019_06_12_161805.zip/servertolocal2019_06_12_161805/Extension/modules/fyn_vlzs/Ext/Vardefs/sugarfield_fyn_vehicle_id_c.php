<?php
 // created: 2018-12-01 10:00:10
$dictionary['fyn_vlzs']['fields']['fyn_vehicle_id_c']['inline_edit']=1;

 ?>