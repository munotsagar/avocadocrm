<?php
 // created: 2018-12-03 17:24:44
$dictionary['fyn_vlzs']['fields']['zone_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['zone_c']['labelValue']='Select Area';

 ?>