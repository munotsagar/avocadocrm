<?php
 // created: 2018-12-03 17:25:17
$dictionary['fyn_vlzs']['fields']['status_c']['inline_edit']='1';
$dictionary['fyn_vlzs']['fields']['status_c']['labelValue']='Status';

 ?>