<?php
//auto-generated file DO NOT EDIT
$layout_defs['fyn_vlzs']['subpanel_setup']['fyn_vlzs_fyn_routes_1']['override_subpanel_name'] = 'fyn_vlzs_subpanel_fyn_vlzs_fyn_routes_1';
?>