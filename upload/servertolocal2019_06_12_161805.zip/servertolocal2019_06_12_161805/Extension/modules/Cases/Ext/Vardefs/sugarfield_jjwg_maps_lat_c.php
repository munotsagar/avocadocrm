<?php
 // created: 2018-11-19 11:15:46
$dictionary['Case']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>