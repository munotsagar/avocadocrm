<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/fyn_qr_code_pallette_fyn_stock_in_1MetaData.php');

?>