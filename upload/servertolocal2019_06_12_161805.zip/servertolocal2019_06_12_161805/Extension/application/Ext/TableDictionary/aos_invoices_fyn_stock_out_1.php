<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/aos_invoices_fyn_stock_out_1MetaData.php');

?>