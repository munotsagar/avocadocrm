<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/fyn_vehicle_vs_vehicle_stockin_1MetaData.php');

?>