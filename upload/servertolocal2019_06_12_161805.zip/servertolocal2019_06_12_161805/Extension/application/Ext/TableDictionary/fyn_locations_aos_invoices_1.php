<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/fyn_locations_aos_invoices_1MetaData.php');

?>