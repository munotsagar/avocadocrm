<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/<basepath>\metadata\aos_products_fyn_stock_in_1MetaData.php');

?>