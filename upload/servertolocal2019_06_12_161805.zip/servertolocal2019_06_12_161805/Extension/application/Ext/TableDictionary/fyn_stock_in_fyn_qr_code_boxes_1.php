<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/fyn_stock_in_fyn_qr_code_boxes_1MetaData.php');

?>