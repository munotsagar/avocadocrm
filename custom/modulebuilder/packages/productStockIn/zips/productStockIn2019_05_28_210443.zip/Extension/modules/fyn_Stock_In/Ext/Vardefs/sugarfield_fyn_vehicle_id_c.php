<?php
 // created: 2018-11-30 13:21:07
$dictionary['fyn_Stock_In']['fields']['fyn_vehicle_id_c']['inline_edit']=1;

 ?>