<?php
 // created: 2019-05-07 09:23:24
$dictionary['AOS_Products']['fields']['warehouse_balance_stocks_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['warehouse_balance_stocks_c']['labelValue']='Warehouse Balance Stocks';

 ?>