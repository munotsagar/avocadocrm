<?php
 // created: 2018-11-19 20:34:22
$dictionary['AOS_Products']['fields']['part_number']['inline_edit']=true;
$dictionary['AOS_Products']['fields']['part_number']['merge_filter']='disabled';

 ?>