<?php
 // created: 2019-05-03 19:18:01
$dictionary['AOS_Products']['fields']['reserve_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['reserve_c']['labelValue']='Reserve';

 ?>