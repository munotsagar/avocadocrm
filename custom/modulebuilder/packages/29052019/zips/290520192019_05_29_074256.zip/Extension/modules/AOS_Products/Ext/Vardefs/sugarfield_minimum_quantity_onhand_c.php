<?php
 // created: 2019-05-07 09:21:38
$dictionary['AOS_Products']['fields']['minimum_quantity_onhand_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['minimum_quantity_onhand_c']['labelValue']='Minimum Quantity On Hand';

 ?>