<?php
 // created: 2019-05-26 19:18:07
$dictionary['fyn_Stock_In']['fields']['vender_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['vender_c']['labelValue']='Vender';

 ?>