<?php
 // created: 2018-11-30 13:21:07
$dictionary['fyn_Stock_In']['fields']['selectvehicle_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['selectvehicle_c']['labelValue']='Select Vehicle';

 ?>