<?php
 // created: 2018-12-12 18:47:10
$dictionary['fyn_Stock_In']['fields']['quantity']['required']=true;
$dictionary['fyn_Stock_In']['fields']['quantity']['default']='1';

 ?>