<?php
 // created: 2019-05-07 09:04:52
$dictionary['AOS_Products']['fields']['backorders_count_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['backorders_count_c']['labelValue']='Backorders Count';

 ?>