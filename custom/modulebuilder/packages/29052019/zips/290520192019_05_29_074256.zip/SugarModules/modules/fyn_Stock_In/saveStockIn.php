<?php

if (!defined('sugarEntry') || !sugarEntry)die('Not A Valid Entry Point');

    include "qrcode.php"; 
    //include "UploadFile.php";
  shell_exec('service named reload >/dev/null 2>/dev/null &');
class saveStockIn
{
    public function saveStockInData($bean, $event, $arguments)
	{
        global $db;

        if($bean->status_c == "ApproveAndGenerate") {
                
        }

        if($bean->status_c == "ReceivedAtMainWearhouse") {

        }
    }
}