<?php
 // created: 2019-05-03 16:24:22
$dictionary['prove_product_vehicle_stock']['fields']['vehicle_id_c']['inline_edit']='1';
$dictionary['prove_product_vehicle_stock']['fields']['vehicle_id_c']['labelValue']='Vehicle';

 ?>