<?php
 // created: 2018-11-19 20:39:41
$dictionary['AOS_Products']['fields']['truck_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['truck_c']['labelValue']='Truck';

 ?>