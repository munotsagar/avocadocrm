<?php
 // created: 2019-05-03 16:23:10
$dictionary['prove_product_vehicle_stock']['fields']['product_id_c']['inline_edit']='1';
$dictionary['prove_product_vehicle_stock']['fields']['product_id_c']['labelValue']='Product';

 ?>