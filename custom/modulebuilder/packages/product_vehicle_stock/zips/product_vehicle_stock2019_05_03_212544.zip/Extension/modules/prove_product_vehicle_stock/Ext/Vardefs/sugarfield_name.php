<?php
 // created: 2019-05-03 16:41:15
$dictionary['prove_product_vehicle_stock']['fields']['name']['required']=false;
$dictionary['prove_product_vehicle_stock']['fields']['name']['inline_edit']=true;
$dictionary['prove_product_vehicle_stock']['fields']['name']['duplicate_merge']='disabled';
$dictionary['prove_product_vehicle_stock']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['prove_product_vehicle_stock']['fields']['name']['merge_filter']='disabled';
$dictionary['prove_product_vehicle_stock']['fields']['name']['unified_search']=false;

 ?>