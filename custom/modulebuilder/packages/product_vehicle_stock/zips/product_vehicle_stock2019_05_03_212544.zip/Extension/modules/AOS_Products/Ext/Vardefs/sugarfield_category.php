<?php
 // created: 2018-12-28 13:06:15
$dictionary['AOS_Products']['fields']['category']['default']='AvacadoClass1';
$dictionary['AOS_Products']['fields']['category']['inline_edit']=true;
$dictionary['AOS_Products']['fields']['category']['massupdate']='1';
$dictionary['AOS_Products']['fields']['category']['merge_filter']='disabled';

 ?>