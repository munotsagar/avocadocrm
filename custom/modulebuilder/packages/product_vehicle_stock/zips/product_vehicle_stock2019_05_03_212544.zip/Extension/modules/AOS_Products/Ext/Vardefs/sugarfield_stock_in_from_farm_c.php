<?php
 // created: 2018-12-28 13:13:05
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['labelValue']='Stock In From Farm';

 ?>