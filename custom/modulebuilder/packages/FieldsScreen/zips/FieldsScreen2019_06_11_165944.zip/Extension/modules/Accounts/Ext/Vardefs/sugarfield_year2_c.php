<?php
 // created: 2019-01-02 23:00:27
$dictionary['Account']['fields']['year2_c']['inline_edit']='1';
$dictionary['Account']['fields']['year2_c']['labelValue']='Year';

 ?>