<?php
 // created: 2018-12-13 11:42:48
$dictionary['Account']['fields']['reseller_certificate_c']['inline_edit']='1';
$dictionary['Account']['fields']['reseller_certificate_c']['labelValue']='Reseller Certificate';

 ?>