<?php
 // created: 2018-11-19 12:56:36
$dictionary['Account']['fields']['comment_c']['inline_edit']='1';
$dictionary['Account']['fields']['comment_c']['labelValue']='Comment';

 ?>