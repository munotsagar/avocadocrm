<?php
 // created: 2018-12-23 15:49:23
$dictionary['Account']['fields']['mob_num_c']['inline_edit']='1';
$dictionary['Account']['fields']['mob_num_c']['labelValue']='mob num';

 ?>