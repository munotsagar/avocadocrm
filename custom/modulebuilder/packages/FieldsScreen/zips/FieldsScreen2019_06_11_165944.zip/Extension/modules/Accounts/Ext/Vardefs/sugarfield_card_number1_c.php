<?php
 // created: 2019-01-02 22:39:56
$dictionary['Account']['fields']['card_number1_c']['inline_edit']='1';
$dictionary['Account']['fields']['card_number1_c']['labelValue']='Card Number';

 ?>