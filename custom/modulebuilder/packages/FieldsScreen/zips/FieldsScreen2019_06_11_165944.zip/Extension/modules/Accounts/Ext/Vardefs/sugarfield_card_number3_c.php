<?php
 // created: 2019-01-02 22:40:41
$dictionary['Account']['fields']['card_number3_c']['inline_edit']='1';
$dictionary['Account']['fields']['card_number3_c']['labelValue']='Card Number';

 ?>