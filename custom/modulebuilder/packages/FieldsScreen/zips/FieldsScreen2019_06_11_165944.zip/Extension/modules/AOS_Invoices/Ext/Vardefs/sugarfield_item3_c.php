<?php
 // created: 2019-01-08 22:00:23
$dictionary['AOS_Invoices']['fields']['item3_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item3_c']['labelValue']='Item3';

 ?>