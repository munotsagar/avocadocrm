<?php
 // created: 2019-06-10 20:10:36
$dictionary['Account']['fields']['reference_2_c']['inline_edit']='1';
$dictionary['Account']['fields']['reference_2_c']['labelValue']='Reference 2';

 ?>