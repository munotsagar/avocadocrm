<?php
 // created: 2018-11-28 14:28:50
$dictionary['AOS_Products']['fields']['stagging_inventory_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stagging_inventory_c']['options']='numeric_range_search_dom';
$dictionary['AOS_Products']['fields']['stagging_inventory_c']['labelValue']='Stagging Inventory';
$dictionary['AOS_Products']['fields']['stagging_inventory_c']['enable_range_search']='1';

 ?>