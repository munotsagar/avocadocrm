<?php
 // created: 2019-01-02 22:43:08
$dictionary['Account']['fields']['ccid1_c']['inline_edit']='1';
$dictionary['Account']['fields']['ccid1_c']['labelValue']='CCID Number';

 ?>