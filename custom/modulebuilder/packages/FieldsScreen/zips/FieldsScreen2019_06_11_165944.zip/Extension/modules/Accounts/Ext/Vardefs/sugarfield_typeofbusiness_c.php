<?php
 // created: 2018-11-19 13:10:10
$dictionary['Account']['fields']['typeofbusiness_c']['inline_edit']='1';
$dictionary['Account']['fields']['typeofbusiness_c']['labelValue']='Type Of Business';

 ?>