<?php
 // created: 2018-11-19 13:04:34
$dictionary['Account']['fields']['customerrating_c']['inline_edit']='1';
$dictionary['Account']['fields']['customerrating_c']['labelValue']='Customer Rating';

 ?>