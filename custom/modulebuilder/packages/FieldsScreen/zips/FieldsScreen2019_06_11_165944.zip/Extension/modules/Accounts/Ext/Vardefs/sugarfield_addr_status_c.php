<?php
 // created: 2018-11-26 08:49:35
$dictionary['Account']['fields']['addr_status_c']['inline_edit']='1';
$dictionary['Account']['fields']['addr_status_c']['labelValue']='Addr Status';

 ?>