<?php
 // created: 2019-01-02 22:29:33
$dictionary['Account']['fields']['card1_c']['inline_edit']='1';
$dictionary['Account']['fields']['card1_c']['labelValue']='Card';

 ?>