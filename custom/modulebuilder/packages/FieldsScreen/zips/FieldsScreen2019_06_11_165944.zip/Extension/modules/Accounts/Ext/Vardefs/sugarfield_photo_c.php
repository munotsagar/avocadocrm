<?php
 // created: 2018-11-19 13:24:56
$dictionary['Account']['fields']['photo_c']['inline_edit']='1';
$dictionary['Account']['fields']['photo_c']['labelValue']='Photo';

 ?>