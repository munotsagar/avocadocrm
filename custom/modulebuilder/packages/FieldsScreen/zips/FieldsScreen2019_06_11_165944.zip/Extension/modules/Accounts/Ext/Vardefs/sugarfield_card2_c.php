<?php
 // created: 2019-01-02 22:33:38
$dictionary['Account']['fields']['card2_c']['inline_edit']='1';
$dictionary['Account']['fields']['card2_c']['labelValue']='Card';

 ?>