<?php
 // created: 2018-11-19 13:08:38
$dictionary['Account']['fields']['maritalstatus_c']['inline_edit']='1';
$dictionary['Account']['fields']['maritalstatus_c']['labelValue']='Marital Status';

 ?>