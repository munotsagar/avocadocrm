<?php
 // created: 2018-11-19 13:22:07
$dictionary['Account']['fields']['customerdiscount_c']['inline_edit']='1';
$dictionary['Account']['fields']['customerdiscount_c']['labelValue']='Customer Discount';

 ?>