<?php
 // created: 2019-06-10 20:11:40
$dictionary['Account']['fields']['reference_3_c']['inline_edit']='1';
$dictionary['Account']['fields']['reference_3_c']['labelValue']='Reference 3';

 ?>