<?php
 // created: 2019-01-02 22:38:03
$dictionary['Account']['fields']['owner2_c']['inline_edit']='1';
$dictionary['Account']['fields']['owner2_c']['labelValue']='Name Appears on the Card';

 ?>