<?php
 // created: 2019-01-02 22:58:25
$dictionary['Account']['fields']['year1_c']['inline_edit']='1';
$dictionary['Account']['fields']['year1_c']['labelValue']='Year';

 ?>