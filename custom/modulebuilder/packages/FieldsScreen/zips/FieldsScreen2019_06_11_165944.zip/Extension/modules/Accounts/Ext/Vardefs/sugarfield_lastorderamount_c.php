<?php
 // created: 2018-11-19 13:46:58
$dictionary['Account']['fields']['lastorderamount_c']['inline_edit']='1';
$dictionary['Account']['fields']['lastorderamount_c']['labelValue']='Last Order Amount';

 ?>