<?php
 // created: 2019-01-02 22:35:36
$dictionary['Account']['fields']['card3_c']['inline_edit']='1';
$dictionary['Account']['fields']['card3_c']['labelValue']='Card';

 ?>