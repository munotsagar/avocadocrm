<?php
 // created: 2019-01-02 22:48:13
$dictionary['Account']['fields']['month2_c']['inline_edit']='1';
$dictionary['Account']['fields']['month2_c']['labelValue']='Month';

 ?>