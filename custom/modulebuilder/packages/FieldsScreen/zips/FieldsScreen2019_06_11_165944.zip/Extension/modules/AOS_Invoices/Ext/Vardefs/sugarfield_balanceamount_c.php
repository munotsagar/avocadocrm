<?php
 // created: 2018-12-15 17:57:05
$dictionary['AOS_Invoices']['fields']['balanceamount_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['balanceamount_c']['labelValue']='Balance Amount';

 ?>