<?php
 // created: 2019-01-02 22:59:48
$dictionary['Account']['fields']['year3_c']['inline_edit']='1';
$dictionary['Account']['fields']['year3_c']['labelValue']='Year';

 ?>