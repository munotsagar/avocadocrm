<?php
 // created: 2019-01-02 22:38:24
$dictionary['Account']['fields']['owner3_c']['inline_edit']='1';
$dictionary['Account']['fields']['owner3_c']['labelValue']='Name Appears on the Card';

 ?>