<?php
 // created: 2018-11-19 13:46:06
$dictionary['Account']['fields']['totalnooforders_c']['inline_edit']='1';
$dictionary['Account']['fields']['totalnooforders_c']['labelValue']='Total No Of Orders';

 ?>