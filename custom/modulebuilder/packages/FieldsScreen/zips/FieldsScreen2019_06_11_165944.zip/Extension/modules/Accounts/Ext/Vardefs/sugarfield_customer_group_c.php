<?php
 // created: 2018-12-12 15:26:55
$dictionary['Account']['fields']['customer_group_c']['inline_edit']='1';
$dictionary['Account']['fields']['customer_group_c']['labelValue']='Customer Group';

 ?>