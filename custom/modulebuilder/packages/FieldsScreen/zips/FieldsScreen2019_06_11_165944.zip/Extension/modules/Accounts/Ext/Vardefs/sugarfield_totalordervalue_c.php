<?php
 // created: 2018-11-19 13:45:23
$dictionary['Account']['fields']['totalordervalue_c']['inline_edit']='1';
$dictionary['Account']['fields']['totalordervalue_c']['labelValue']='Total Order Value';

 ?>