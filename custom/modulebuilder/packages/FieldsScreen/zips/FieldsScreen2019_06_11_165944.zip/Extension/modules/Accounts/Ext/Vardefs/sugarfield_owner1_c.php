<?php
 // created: 2019-01-02 22:39:00
$dictionary['Account']['fields']['owner1_c']['inline_edit']='1';
$dictionary['Account']['fields']['owner1_c']['labelValue']='Name Appears on the Card';

 ?>