<?php
 // created: 2019-01-02 22:43:27
$dictionary['Account']['fields']['ccid2_c']['inline_edit']='1';
$dictionary['Account']['fields']['ccid2_c']['labelValue']='CCID Number';

 ?>