<?php
 // created: 2019-01-02 22:44:36
$dictionary['Account']['fields']['add_notes1_c']['inline_edit']='1';
$dictionary['Account']['fields']['add_notes1_c']['labelValue']='Additional Notes';

 ?>