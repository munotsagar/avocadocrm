<?php
 // created: 2018-11-19 13:03:16
$dictionary['Account']['fields']['nationality_c']['inline_edit']='1';
$dictionary['Account']['fields']['nationality_c']['labelValue']='Nationality';

 ?>