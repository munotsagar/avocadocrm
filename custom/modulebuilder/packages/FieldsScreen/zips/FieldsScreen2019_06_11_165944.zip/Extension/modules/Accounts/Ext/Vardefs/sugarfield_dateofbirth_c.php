<?php
 // created: 2018-11-19 13:10:50
$dictionary['Account']['fields']['dateofbirth_c']['inline_edit']='1';
$dictionary['Account']['fields']['dateofbirth_c']['labelValue']='Date of Birth';

 ?>