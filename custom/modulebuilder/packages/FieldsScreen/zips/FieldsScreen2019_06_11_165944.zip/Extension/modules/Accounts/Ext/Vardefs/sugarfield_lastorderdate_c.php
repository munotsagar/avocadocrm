<?php
 // created: 2018-11-19 13:46:35
$dictionary['Account']['fields']['lastorderdate_c']['inline_edit']='1';
$dictionary['Account']['fields']['lastorderdate_c']['labelValue']='Last Order Date';

 ?>