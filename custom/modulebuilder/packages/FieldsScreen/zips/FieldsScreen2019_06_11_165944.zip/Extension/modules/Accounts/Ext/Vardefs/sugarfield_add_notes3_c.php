<?php
 // created: 2019-01-02 22:45:14
$dictionary['Account']['fields']['add_notes3_c']['inline_edit']='1';
$dictionary['Account']['fields']['add_notes3_c']['labelValue']='Additional Notes';

 ?>