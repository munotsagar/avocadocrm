<?php
 // created: 2019-05-19 12:40:48
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stock_in_from_farm_c']['labelValue']='Last Translation Stock In From Farm';

 ?>