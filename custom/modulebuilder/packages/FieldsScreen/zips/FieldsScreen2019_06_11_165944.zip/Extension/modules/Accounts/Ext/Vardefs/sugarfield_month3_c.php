<?php
 // created: 2019-01-09 22:07:09
$dictionary['Account']['fields']['month3_c']['inline_edit']='1';
$dictionary['Account']['fields']['month3_c']['labelValue']='Month';

 ?>