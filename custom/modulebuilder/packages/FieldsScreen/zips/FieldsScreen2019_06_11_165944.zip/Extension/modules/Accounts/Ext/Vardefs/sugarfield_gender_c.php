<?php
 // created: 2018-11-19 13:16:13
$dictionary['Account']['fields']['gender_c']['inline_edit']='1';
$dictionary['Account']['fields']['gender_c']['labelValue']='Gender';

 ?>