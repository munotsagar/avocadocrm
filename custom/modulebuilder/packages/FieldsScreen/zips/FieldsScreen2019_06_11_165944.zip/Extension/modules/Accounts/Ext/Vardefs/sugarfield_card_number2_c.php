<?php
 // created: 2019-01-02 22:40:25
$dictionary['Account']['fields']['card_number2_c']['inline_edit']='1';
$dictionary['Account']['fields']['card_number2_c']['labelValue']='Card Number';

 ?>