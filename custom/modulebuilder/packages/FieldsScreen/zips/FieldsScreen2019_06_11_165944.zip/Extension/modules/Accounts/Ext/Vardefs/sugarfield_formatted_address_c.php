<?php
 // created: 2018-11-26 08:46:37
$dictionary['Account']['fields']['formatted_address_c']['inline_edit']='1';
$dictionary['Account']['fields']['formatted_address_c']['labelValue']='Formatted Address';

 ?>