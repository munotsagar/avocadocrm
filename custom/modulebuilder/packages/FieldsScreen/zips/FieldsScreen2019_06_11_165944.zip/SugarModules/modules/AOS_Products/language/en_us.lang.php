<?php 
 // created: 2019-06-11 16:59:24
$mod_strings['LBL_CUSTOMERS_PURCHASED_PRODUCTS_SUBPANEL_TITLE'] = 'Purchases';
$mod_strings['LBL_PART_NUMBER'] = 'Product ID';
$mod_strings['LBL_TYPE'] = 'Warehouse Stock Status';
$mod_strings['LBL_TRUCK'] = 'Truck';
$mod_strings['LBL_STOCKIN'] = 'Total Products In Hand';
$mod_strings['LBL_STOCKOUT'] = 'Stock Out';
$mod_strings['LBL_BALANCE'] = 'Warehouse Balance Stock';
$mod_strings['LBL_PRODUCT_MODEL_CODE'] = 'Product Model Code';
$mod_strings['LBL_STAGGING_INVENTORY'] = 'Today&#039;s New Orders';
$mod_strings['LBL_OPENCARTBALANCESTOCK'] = 'Balance Stock after New Orders';
$mod_strings['LBL_AOS_PRODUCTS_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE'] = 'Stock Out';
$mod_strings['LBL_AOS_PRODUCTS_FYN_STOCK_IN_1_FROM_FYN_STOCK_IN_TITLE'] = 'Stock In';
$mod_strings['LBL_AOS_PRODUCTS_FYN_QR_CODE_BOXES_1_FROM_FYN_QR_CODE_BOXES_TITLE'] = 'QR Code Boxes';
$mod_strings['LBL_MAINCODE'] = 'OpenCart Stock Status';
$mod_strings['LBL_AOS_PRODUCTS_VS_VEHICLE_STOCKIN_1_FROM_VS_VEHICLE_STOCKIN_TITLE'] = 'Vehicle StockIN';
$mod_strings['LBL_AOS_PRODUCTS_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LBL_ORDER_UPDATE_DAILY'] = 'Order Update Daily';
$mod_strings['LBL_FOR_DAILYUPDATEORDER'] = 'For Daily update order';
$mod_strings['LBL_CATEGORY'] = 'Product Category';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Transfers';
$mod_strings['LBL_STOCK_IN_FROM_FARM'] = 'Last Translation Stock In From Farm';
$mod_strings['LBL_DISPOSABLE'] = 'Disposable';
$mod_strings['LBL_RESERVE'] = 'Reserve';
$mod_strings['LBL_BACKORDERS_COUNT'] = 'Backorders Count';
$mod_strings['LBL_MINIMUM_QUANTITY_ONHAND'] = 'Minimum Quantity On Hand';
$mod_strings['LBL_WAREHOUSE_BALANCE_STOCKS'] = 'Warehouse Balance Stocks';
$mod_strings['LBL_DEFECT'] = 'Defect';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Transfers';
$mod_strings['LBL_INVOICE_STOCK'] = 'Invoice Stock';
$mod_strings['LBL_PRODUCT_QR_CODE'] = 'Product QR Code';

?>
