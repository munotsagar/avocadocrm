<?php
 // created: 2019-05-03 19:16:32
$dictionary['AOS_Products']['fields']['disposable_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['disposable_c']['labelValue']='Disposable';

 ?>