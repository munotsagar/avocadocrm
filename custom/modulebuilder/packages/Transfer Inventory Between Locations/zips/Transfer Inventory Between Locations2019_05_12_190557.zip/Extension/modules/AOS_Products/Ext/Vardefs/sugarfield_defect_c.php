<?php
 // created: 2019-05-12 08:33:41
$dictionary['AOS_Products']['fields']['defect_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['defect_c']['labelValue']='Defect';

 ?>