<?php
 // created: 2018-12-13 19:16:58
$dictionary['AOS_Products']['fields']['order_update_daily_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['order_update_daily_c']['labelValue']='Order Update Daily';

 ?>