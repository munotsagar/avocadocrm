<?php
 // created: 2018-11-19 20:42:39
$dictionary['AOS_Products']['fields']['stockin_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stockin_c']['labelValue']='Stock In';

 ?>