<?php 
$app_list_strings['from1_list'] = array (
  '' => '',
  'Farm' => 'Farm',
  'Vehiclereturn' => 'Vehicle Return',
);$app_list_strings['status_list'] = array (
  'Draft' => 'Draft',
  'ApproveAndGenerate' => 'ApproveAndGenerate',
  'InTransit' => 'InTransit',
  'ReceivedAtMainWearhouse' => 'ReceivedAtMainWearhouse',
);$app_list_strings['vender_list'] = array (
  'Farm1' => 'Farm1',
  'Farm2' => 'Farm2',
  'Farm3' => 'Farm3',
);