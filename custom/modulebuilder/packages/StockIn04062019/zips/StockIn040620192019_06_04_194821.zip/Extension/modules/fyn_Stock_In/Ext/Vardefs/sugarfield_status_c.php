<?php
 // created: 2019-05-26 19:38:20
$dictionary['fyn_Stock_In']['fields']['status_c']['inline_edit']='1';
$dictionary['fyn_Stock_In']['fields']['status_c']['labelValue']='Status';

 ?>