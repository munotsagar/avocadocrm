<?php
 // created: 2018-12-01 00:31:45
$dictionary['fyn_Stock_In']['fields']['name']['required']=false;
$dictionary['fyn_Stock_In']['fields']['name']['full_text_search']=array (
);

 ?>