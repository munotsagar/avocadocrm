<?php
 // created: 2019-01-10 01:30:16
$dictionary['AOS_Invoices']['fields']['item6_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item6_c']['labelValue']='Item6';

 ?>