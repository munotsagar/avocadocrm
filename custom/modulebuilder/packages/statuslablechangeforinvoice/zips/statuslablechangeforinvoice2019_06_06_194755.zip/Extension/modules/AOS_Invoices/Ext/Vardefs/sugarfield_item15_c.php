<?php
 // created: 2019-01-10 01:32:28
$dictionary['AOS_Invoices']['fields']['item15_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item15_c']['labelValue']='Item15';

 ?>