<?php
 // created: 2018-12-03 14:53:21
$dictionary['AOS_Invoices']['fields']['formatted_address_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['formatted_address_c']['labelValue']='Formatted Address';

 ?>