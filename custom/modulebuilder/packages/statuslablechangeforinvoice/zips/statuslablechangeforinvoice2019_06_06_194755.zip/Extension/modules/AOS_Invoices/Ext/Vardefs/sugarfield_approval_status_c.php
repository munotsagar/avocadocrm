<?php
 // created: 2019-06-06 16:18:23
$dictionary['AOS_Invoices']['fields']['approval_status_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['approval_status_c']['labelValue']='Invoice Status';

 ?>