<?php
 // created: 2018-12-04 21:06:18
$dictionary['AOS_Invoices']['fields']['customerid_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['customerid_c']['labelValue']='CustomerID';

 ?>