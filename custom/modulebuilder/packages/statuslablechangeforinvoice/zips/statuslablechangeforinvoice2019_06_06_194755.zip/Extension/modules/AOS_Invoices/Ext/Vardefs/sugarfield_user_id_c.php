<?php
 // created: 2018-12-11 11:57:17
$dictionary['AOS_Invoices']['fields']['user_id_c']['inline_edit']=1;

 ?>