<?php
 // created: 2018-11-19 20:43:14
$dictionary['AOS_Products']['fields']['balance_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['balance_c']['labelValue']='Balance Stock';

 ?>