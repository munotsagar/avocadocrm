<?php
 // created: 2018-11-28 14:31:18
$dictionary['AOS_Products']['fields']['opencartbalancestock_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['opencartbalancestock_c']['labelValue']='Opencart Balance Stock';

 ?>