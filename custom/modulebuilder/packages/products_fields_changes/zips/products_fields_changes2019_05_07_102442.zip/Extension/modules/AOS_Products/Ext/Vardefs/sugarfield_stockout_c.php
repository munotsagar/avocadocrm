<?php
 // created: 2018-11-19 20:42:52
$dictionary['AOS_Products']['fields']['stockout_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['stockout_c']['labelValue']='Stock Out';

 ?>