<?php
 // created: 2019-01-16 16:09:37
$dictionary['AOS_Invoices']['fields']['due_dates_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['due_dates_c']['labelValue']='Due Date';

 ?>