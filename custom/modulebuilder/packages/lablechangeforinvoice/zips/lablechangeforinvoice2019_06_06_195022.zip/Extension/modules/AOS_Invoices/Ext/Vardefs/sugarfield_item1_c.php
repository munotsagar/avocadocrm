<?php
 // created: 2019-01-08 22:00:07
$dictionary['AOS_Invoices']['fields']['item1_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item1_c']['labelValue']='Item1';

 ?>