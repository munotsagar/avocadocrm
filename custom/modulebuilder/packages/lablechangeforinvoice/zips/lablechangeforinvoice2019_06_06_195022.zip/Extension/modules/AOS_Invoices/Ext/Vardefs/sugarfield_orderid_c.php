<?php
 // created: 2018-12-04 21:06:42
$dictionary['AOS_Invoices']['fields']['orderid_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['orderid_c']['labelValue']='OrderID';

 ?>