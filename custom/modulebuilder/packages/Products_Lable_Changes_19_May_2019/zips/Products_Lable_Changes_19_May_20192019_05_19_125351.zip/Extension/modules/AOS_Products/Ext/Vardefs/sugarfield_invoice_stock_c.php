<?php
 // created: 2019-05-19 12:49:22
$dictionary['AOS_Products']['fields']['invoice_stock_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['invoice_stock_c']['labelValue']='Invoice Stock';

 ?>