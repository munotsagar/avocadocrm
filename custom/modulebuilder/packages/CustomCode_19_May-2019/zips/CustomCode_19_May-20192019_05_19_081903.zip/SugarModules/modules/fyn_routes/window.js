$(document).ready(function(){ 
  function myButtonFunt(){ 
     window.open("https://www.w3schools.com");
  }
});