<?php 
 // created: 2019-05-19 08:19:02
$mod_strings['LBL_FYN_ROUTES_OP_ORDERS_1_FROM_OP_ORDERS_TITLE'] = 'Orders';
$mod_strings['LBL_FYN_VLZS_FYN_ROUTES_1_FROM_FYN_VLZS_TITLE'] = 'Vehicle and Area';
$mod_strings['LNK_NEW_RECORD'] = 'Create Routes';
$mod_strings['LNK_LIST'] = 'View Routes';
$mod_strings['LNK_IMPORT_FYN_ROUTES'] = 'Import Routes';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Routes List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Routes';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Routes';
$mod_strings['LBL_ZIPCODE_C'] = 'Zip Code';
$mod_strings['LBL_DATE_ENTERED'] = 'Routing Date';
$mod_strings['LBL_DESCRIPTION'] = 'Routing Description';

?>
