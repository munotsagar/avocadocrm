<?php

//print_r($_REQUEST);
global $db;
$selectInvoices = $_REQUEST['selectInvoice'];
$route = $_REQUEST['route'];
$van = $_REQUEST['van'];

$countInvoice = count($selectInvoices);

if($countInvoice > 0 ) {
    
    foreach($selectInvoices as $selectInvoice) {
        $db->query("delete from route_invoice_van where invoice = '".$selectInvoice."' and route = '".$route."'");
        $db->query("insert into route_invoice_van (invoice, route, van) VALUES('".$selectInvoice."', '".$route."', '".$van."')");
    }
}
header("Location: index.php?module=fyn_routes&action=DetailView&record=".$route);
?>