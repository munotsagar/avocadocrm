<?php
 // created: 2018-12-01 16:36:46
$dictionary['fyn_routes']['fields']['zipcode_c']['inline_edit']='1';
$dictionary['fyn_routes']['fields']['zipcode_c']['labelValue']='Zip Code';

 ?>