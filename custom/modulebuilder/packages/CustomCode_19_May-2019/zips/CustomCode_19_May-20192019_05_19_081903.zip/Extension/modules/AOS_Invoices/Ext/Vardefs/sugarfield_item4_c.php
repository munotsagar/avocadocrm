<?php
 // created: 2019-01-08 22:00:32
$dictionary['AOS_Invoices']['fields']['item4_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item4_c']['labelValue']='Item4';

 ?>