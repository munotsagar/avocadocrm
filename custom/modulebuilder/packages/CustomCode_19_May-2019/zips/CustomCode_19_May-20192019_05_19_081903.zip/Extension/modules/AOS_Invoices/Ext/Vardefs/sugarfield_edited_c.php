<?php
 // created: 2018-12-20 19:34:08
$dictionary['AOS_Invoices']['fields']['edited_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['edited_c']['labelValue']='edited';

 ?>