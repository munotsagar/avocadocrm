<?php
 // created: 2018-12-04 21:15:13
$dictionary['AOS_Invoices']['fields']['approval_status_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['approval_status_c']['labelValue']='Order Status';

 ?>