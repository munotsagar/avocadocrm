<?php
 // created: 2019-01-16 15:51:25
$dictionary['AOS_Invoices']['fields']['due_date']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['due_date']['merge_filter']='disabled';

 ?>