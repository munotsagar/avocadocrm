<?php
 // created: 2019-01-10 01:30:01
$dictionary['AOS_Invoices']['fields']['item5_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item5_c']['labelValue']='Item5';

 ?>