<?php
 // created: 2018-12-03 14:52:24
$dictionary['AOS_Invoices']['fields']['addr_status_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['addr_status_c']['labelValue']='Address Status';

 ?>