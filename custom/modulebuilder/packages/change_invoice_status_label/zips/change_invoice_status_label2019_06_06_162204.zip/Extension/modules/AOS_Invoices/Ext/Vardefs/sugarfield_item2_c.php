<?php
 // created: 2019-01-08 22:00:16
$dictionary['AOS_Invoices']['fields']['item2_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['item2_c']['labelValue']='Item2';

 ?>